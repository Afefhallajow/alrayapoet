<?php $__env->startPush('css'); ?>
<style>
   h4{
      color: white;
   }
   h2{
      color: white;
   }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row ">
       <div class="col-sm-12 col-lg-12">
              <form action="<?php echo e(url()->current()); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <label>
                      الملاحطة
                  </label>
                  <textarea name="note" class="form-control"></textarea><br>
                  <button class="btn btn-primary" type="submit">
                      إرسال
                  </button>
              </form>
       </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.appp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alrayapoet/public_html/vision/resources/views/generate_link_view.blade.php ENDPATH**/ ?>