
<?php $__env->startSection('css'); ?>
    <style>
        .red{
            color:red;
        }
        .error{
            color:red;
        }
        .alert-danger {
            background-color: red !important;
        }
    </style>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="content">
                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <!-- DataTales Example -->
                    <div class="card shadow mb-2">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">
                                <a class="btn" data-toggle="modal" data-target="#exampleModal" style="font-weight:bold;float:right;font-size:1.2rem">  جدول المستخدمين</a>
                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
                                 إضافة مستخدم جديد 
                                </button>
                            </h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered yajra-datatable"  width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>التسلسل</th>
                                            <th> الاسم</th>
                                            <th>الإيميل</th>
                                            <th>نوع المستخدم</th>
                                            <th>الإجراء</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

            </div>
            <!-- /.container-fluid -->

            </div>
            
            <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">إضافة مستخدم جديد</h5>
      </div>
      <form action="<?php echo e(url()->current()); ?>" method="post" id="addNewUser">
          <?php echo csrf_field(); ?>
          <div class="modal-body">
            <label for="name">نوع المستخدم</label>
            <select class="form-control" name="type" id="type">
                <option value="1">Admin</option>
                <option value="3">View Only</option>
            </select><br>
            <label for="name">الاسم</label>
            <input type="text" dir="trl" class="form-control" name="name" id="name" required/>
            <label for="speaker">الإيميل </label>
            <input type="email" dir="trl" class="form-control" name="email" id="email" required/>
            <label for="day">كلمة المرور </label>
            <input type="password" dir="trl" class="form-control" name="password" id="password" required/>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary closeModal" data-dismiss="modal">إغلاق</button>
            <button type="submit" class="btn btn-primary">حفظ </button>
          </div>
      </form>
    </div>
  </div>
</div>

<?php $__env->startPush('style'); ?>

    <link href="<?php echo e(asset('assets/SmartWizard/bootstrap.css')); ?>" rel="stylesheet" type="text/css" />
    
    
    
    
    <link href="<?php echo e(asset('assets/SmartWizard/theme-ar.css')); ?>" rel="stylesheet" type="text/css" />

<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>

    <script src="<?php echo e(asset('assets/SmartWizard/jquery.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/SmartWizard/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/SmartWizard/custom_js.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/SmartWizard/validator.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/admin/lib/SmartWizard/dist/js/jquery.smartWizard.js')); ?>"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-validator/0.5.3/js/bootstrapValidator.js"></script>
    <script type="text/javascript">
    var serialNumber = 0;
    $(function () {

        $.ajaxSetup({
                  headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                  }
        });
        
        var table = $('.yajra-datatable').DataTable({
            processing: true,
            serverSide: true,
            ajax: "<?php echo e(route('getAllUsers')); ?>",
            columns: [
                {data: 'id', name: 'id'},
                {data: 'name', name: 'name'},
                {data: 'email', name: 'email'},
                {data: 'type', name: 'type'},
                {
                    data: 'action', 
                    name: 'action', 
                    orderable: true, 
                    searchable: true
                },
            ] ,
            columnDefs: [
                {
                // For Responsive
                responsivePriority: 13,
                targets: 0
                },
                {
                    targets: 0,
                    render: function (data, type, full) {
                        return ++serialNumber;

                    }
                },
                {
                    targets: 1,
                    render: function (data, type, full) {
                        var text = full['name'];
                        return text;

                    }
                },
                {
                    targets: 2,
                    render: function (data, type, full) {
                        var text = full['email'];
                        return text;

                    }
                },
                {
                    targets: 3,
                    render: function (data, type, full) {
                        var text = full['type'];
                        return text;

                    }
                },
                {
                // Actions
                targets: 4,
                render: function (data, type, full, meta) {
                    var id = full['id'];
                    var name = full['name'];
                    var email = full['email'];
                        return (
                            '<div>' +
                            '<a style="text-align:center" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#exampleModal'+id+'"> <i class="fa fa-edit"></i></a>'+
                            '</div>'+
                            '<div class="modal fade" id="exampleModal'+id+'" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">'+
                              '<div class="modal-dialog" role="document">'+
                                '<div class="modal-content">'+
                                  '<div class="modal-header">'+
                                    '<h5 class="modal-title" id="exampleModalLabel">Update Info</h5>'+
                                  '</div>'+
                                  '<form action="/vision/edit-user/'+id+'" id="updateUser'+id+'" class="updateUser">'+
                                  '<div class="modal-body">'+
                                 
                                  '<label for="name">الاسم</label>'+
                                  '<input type="text" dir="trl" class="form-control" value="'+name+'" name="name"  required/>'+
                                  '<label for="speaker">الإيميل </label>'+
                                  '<input type="email" dir="trl" class="form-control" value="'+email+'" name="email"  required/>'+
                                  '<label for="day">كلمة المرور </label>'+
                                  '<input type="password" dir="trl" class="form-control" name="password" />'+
                                  '<p>تجاهل حقل كلمة المرور في حال كنت لاترغب بتغييرها</p>'+
                                  '</div>'+
                                  '<div class="modal-footer">'+
                                    '<button type="button" class="btn btn-secondary" data-dismiss="modal">إغلاق</button>'+
                                    '<button type="submit" class="btn btn-primary">حفظ</button>'+
                                  '</div>'+
                                  '</form>'+
                                '</div>'+
                              '</div>'+
                            '</div>'
                         
                        );
                }
                }
            ]
        });

        $(document).on('submit', '#addNewUser', function (e) {
            e.preventDefault();

            var url = $(this).attr('action');
            var data = $(this).serialize();
            $.ajaxSetup({
                  headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                  }
            });
            $.ajax({
                'url': url,
                'type': 'post',
                'dataType': 'json',
                data: data,
                success: function (response) {
                    toastr.success('تمت إضافة المستخدم بنجاح');
                    table.ajax.reload();
                    $(".closeModal").click();
                },
                error: function (xhr) {
                    toastr.error('حدث خطأ ما');
                    $(".closeModal").click();
                }
            });

        });
        
        
        $(document).on('submit', '.updateUser', function (e) {
            e.preventDefault();

            var url = $(this).attr('action');
            var data = $(this).serialize();
            $.ajaxSetup({
                  headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                  }
            });
            $.ajax({
                'url': url,
                'type': 'post',
                'dataType': 'json',
                data: data,
                success: function (response) {
                    toastr.success('تمت تعديل المستخدم بنجاح');
                    table.ajax.reload();
                    location.reload();
                },
                error: function (xhr) {
                    toastr.error('حدث خطأ ما');
                    $(".closeModal").click();
                }
            });

        });

        $('#myModal').on('shown.bs.modal', function () {
            $('#myInput').trigger('focus')
        });
        
    });
    </script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/visionpoet/public_html/vision/resources/views/admin/add_new_user.blade.php ENDPATH**/ ?>