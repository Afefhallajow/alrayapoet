
<!doctype html>
<html lang="en-US">

<head>
    <meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
    <title>مهرجمهرجان الخليج للإذاعة والتلفزيون
</title>
    <meta name="description" content="New Account Email Template.">
    <style type="text/css">
        a:hover {text-decoration: underline !important;}
        @font-face {font-family: "FrutigerLTArabic-75Black"; src: url("//db.onlinewebfonts.com/t/593331e50d21b6415d53fc7c416b5b8e.eot"); src: url("//db.onlinewebfonts.com/t/593331e50d21b6415d53fc7c416b5b8e.eot?#iefix") format("embedded-opentype"), url("//db.onlinewebfonts.com/t/593331e50d21b6415d53fc7c416b5b8e.woff2") format("woff2"), url("//db.onlinewebfonts.com/t/593331e50d21b6415d53fc7c416b5b8e.woff") format("woff"), url("//db.onlinewebfonts.com/t/593331e50d21b6415d53fc7c416b5b8e.ttf") format("truetype"), url("//db.onlinewebfonts.com/t/593331e50d21b6415d53fc7c416b5b8e.svg#FrutigerLTArabic-75Black") format("svg"); }
    </style>
</head>

<body marginheight="0" topmargin="0" marginwidth="0" style="margin: 0px; background-color: #f2f3f8;" leftmargin="0" dir="rtl">
    <!-- 100% body table -->
    <table cellspacing="0" border="0" cellpadding="0" width="100%" bgcolor="#f2f3f8"

    style="@import  url(//db.onlinewebfonts.com/c/593331e50d21b6415d53fc7c416b5b8e?family=FrutigerLTArabic-75Black); font-family: 'FrutigerLTArabic-75Black', sans-serif;">
        <tr>
            <td>
                <table style="background-color: #f2f3f8; max-width:670px; margin:0 auto;" width="100%" border="0"
                    align="center" cellpadding="0" cellspacing="0">
                    <tr>
                        <td style="height:80px;">&nbsp;</td>
                    </tr>
                    <tr>
                        <td style="text-align:center;">
                            <a href="https://rakeshmandal.com" title="logo" target="_blank">
                            <img width="250" src="<?php echo e(asset('/public/assets/logo.png')); ?>" title="logo" alt="logo">
                          </a>
                        </td>
                    </tr>
                    <tr>
                        <td style="height:20px;">&nbsp;</td>
                    </tr>
                    <tr>
                        <td>
                            <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0"
                                style="max-width:670px; background:#fff; border-radius:3px; text-align:center;-webkit-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);-moz-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);box-shadow:0 6px 18px 0 rgba(0,0,0,.06);">
                                <tr>
                                    <td style="height:40px;">&nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="padding:0 35px;">
                                        <h1 style="color:#d09b3d; font-weight:500; margin:0;font-size:25px;font-family:'FrutigerLTArabic-75Black',sans-serif;"> 
                                        تم استلام مشاركتك بنجاح
                                        شكراً لمشاركتك في برنامج شاعر الرؤية
                                        
                                        </h1>
                                        <p style="font-size:15px; color:#455056; margin:8px 0 0; line-height:24px;">
                                           
                 
                 
        </strong>
        <!--(The Art)-->
        <!--جزيرة أمواج-->
        <!--في الفترة 21-22-23 يونيو 2022-->
        </p>



        <span style="display:inline-block; vertical-align:middle; margin:29px 0 26px; border-bottom:1px solid #cecece; width:100px;"></span>

      


                               </td>
                                </tr>
                                <tr>
                                    <td style="height:40px;">&nbsp;</td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                   
                   
                   
                    <tr>
                        <td style="text-align:center; height:20px; background:#d09b3d ">
                      <br>
                    <p style="font-size:14px;  line-height:20px; margin:0 0 0;color:#fff; font-family:sans-serif;">&copy; <strong>visionpoet.com</strong> </p>


                    <ul style="padding: 5px;" >

        <li style=" display: inline;padding: 2px;" ><a href="https://twitter.com/thevisionpoet?s=11&t=719aQwg25Yla0hWOoZFOGg"><img width="25" src="https://festival-gcc.org/public/twitter.png"  alt=""></a></li>
        <li style=" display: inline;padding: 2px;"><a href="https://www.instagram.com/thevisionpoet/?igshid=YmMyMTA2M2Y%3D"><img width="25" src="https://festival-gcc.org/public/instagram.png"  alt=""></a></li>
        <li style=" display: inline;padding: 2px;"><a href="https://t.snapchat.com/CDDdDny5"><img width="25" src="https://festival-gcc.org/public/snapchat.png"  alt=""></a></li>
        <li style=" display: inline;padding: 2px;"><a href="https://www.tiktok.com/@thevisionpoet?_d=secCgYIASAHKAESPgo8957e5Vth7mf6%2B6fKA9iBZ%2Bc2Q9%2Bnr2t%2BTMfkyPEoOjtsn2WqiMETyrHETMVifcL15D0qI%2FXgKChC2rXZGgA%3D&_r=1&language=en&sec_uid=MS4wLjABAAAA6f1zr2nsvr7XALmpRzBAxTq5x4sWaoKhNhGfOdNEzmgPQa9tcf2a64bBRdMhH9-w&share_app_id=1233&share_author_id=7119445643873256453&share_link_id=9EA25A2C-C733-46B3-B5CA-7D321A1CCEF6&source=h5_m&timestamp=1657983450&tt_from=copy&ug_btm=b6880%2Cb5836&utm_campaign=client_share&utm_medium=ios&utm_source=copy"><img width="25" src="https://festival-gcc.org/public/tiktok.png"  alt=""></a></li>
      </ul>



                        </td>

                    </tr>
                    
                    
                    
                    
                    
                    <tr>
                        <td style="height:80px;">&nbsp;</td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
    <!--/100% body table-->
</body>

</html>
<?php /**PATH /home/visionpoet/public_html/vision/resources/views/email/welcome.blade.php ENDPATH**/ ?>