<?php $__env->startPush('css'); ?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Arabic&display=swap" rel="stylesheet">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Noto+Naskh+Arabic&display=swap" rel="stylesheet">
<style>
   h4{
      color: white;
   }
   h2{
      color: white;
   }
   #myChartGender{
       width:8rem !important;
       height:8rem !important;
       margin:auto;
   }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

       <?php if(Auth::user()->type == 1 || Auth::user()->type == 3): ?>
            <div class="col-sm-12 col-lg-12 pb-2">
                <button id="export-report" class="btn btn-primary">Export</button>
            </div>
        <?php endif; ?>
    <div class="row" id="canvas_image" style="word-wrap: normal;font-family: 'Noto Sans Arabic', sans-serif;text-align: right;letter-spacing: normal !important;">
     <?php if(Auth::user()->type == 2 || Auth::user()->type == 4): ?>
       <div class="col-sm-12 col-lg-6">
          <div class="card shadow-base bg-primary card-img-holder text-white">
             <div class="card-body">
                <?php if(Auth::user()->type == 4): ?>
                    <h4 class=" mb-2 text-center" style="word-wrap: normal;font-family: 'Noto Sans Arabic', sans-serif;">
                       المتأهلين
                    </h4>
                    <h2 class="mb-0 text-center">
                         <?php echo e($doneEv); ?>

                    </h2>
                 <?php endif; ?>
                <?php if(Auth::user()->type == 2): ?>
                    <h4 class=" mb-2 text-center" style="word-wrap: normal;font-family: 'Noto Sans Arabic', sans-serif;">
                        متقدمين تم تقييمهم
                    </h4>
                    <h2 class="mb-0 text-center" >
                         <?php echo e($doneEv); ?>

                    </h2>
                <?php endif; ?>
             </div>
          </div>
       </div>
       <div class="col-sm-12 col-lg-6">
          <div class="card shadow-base bg-success card-img-holder text-white">
             <div class="card-body">
                 <?php if(Auth::user()->type == 4): ?>
                    <h4 class=" mb-2 text-center">
                        المرشحين
                    </h4>
                    <h2 class="mb-0 text-center">
                       <?php echo e($needEv); ?>

                    </h2>
                 <?php endif; ?>
                <?php if(Auth::user()->type == 2): ?>
                    <h4 class=" mb-2 text-center">
                        متقدمين بحاجة للتقييم  
                    </h4>
                    <h2 class="mb-0 text-center">
                       <?php echo e($needEv); ?>

                    </h2>
                <?php endif; ?>
             </div>
          </div>
       </div>
      <?php endif; ?>
       <?php if(Auth::user()->type == 1 || Auth::user()->type == 3): ?>
        <div class="col-sm-12 col-lg-3">
          <div class="card shadow-base card-img-holder">
             <div class="card-body" style="height:11rem">
                    <h2 class=" mb-2 text-center" style="color: #66617a;font-weight: bold;font-family: 'Noto Sans Arabic', sans-serif;letter-spacing: normal !important;">
                       المتقدمين
                    </h2>
                    <br>
                    <h1 class="mb-0 text-center" style="color: #66617a;font-weight: bold;">
                         354
                    </h1>
             </div>
          </div>
       </div>
       <div class="col-sm-12 col-lg-3">
          <div class="card shadow-base card-img-holder">
             <div class="card-body" style="height:11rem">
                    <h2 class=" mb-2 text-center" style="color: #66617a;font-weight: bold;">
                       المرشحين
                    </h2>
                    <br>
                    <h1 class="mb-0 text-center" style="color: #66617a;font-weight: bold;">
                         97
                    </h1>
             </div>
          </div>
       </div>
       <div class="col-sm-12 col-lg-3">
          <div class="card shadow-base card-img-holder">
             <div class="card-body" style="height:11rem">
                    <h2 class=" mb-2 text-center" style="color: #66617a;font-weight: bold;font-family: 'Noto Naskh Arabic', serif;">
                       المشاركين
                    </h2>
                    <br>
                    <h1 class="mb-0 text-center" style="color: #66617a;font-weight: bold;">
                         <?php echo e($data['FinalResult']); ?>

                    </h1>
             </div>
          </div>
       </div>
       <div class="col-sm-12 col-lg-3">
            <div class="card shadow-base card-img-holder">
                <div class="card-body">
                    <canvas id="myChartGender"></canvas>
                </div>
            </div>
        </div>
       <div class="col-sm-12 col-lg-4" style="margin-bottom:2rem">
           <h1 style="text-align:center">جنسيات المشاركين</h1>
            <canvas id="myChartCountries"></canvas>
        </div>
       <div class="col-sm-12 col-lg-8" style="margin-bottom:2rem">
           <h1 style="text-align:center"></h1>
            <canvas id="myChartAllCounts"></canvas>
        </div>
        <!-- -->
        <div class="col-sm-12 col-lg-4"></div>
        <div class="col-sm-12 col-lg-4"></div>
        <div class="col-sm-12 col-lg-4"></div>
        <div class="col-sm-12 col-lg-4"></div>
        <div class="col-sm-12 col-lg-4"><h1 style="margin:1rem 0 4rem 0;">الأعضاء ضمن لجنة التحكيم </h1></div>
        <div class="col-sm-12 col-lg-4"></div>
        <hr>
        <!-- -->
       <div class="col-sm-12 col-lg-4">
            <canvas id="myChart6"></canvas>
            <h1>خالد المريخي</h1>
        </div>
       <div class="col-sm-12 col-lg-4">
            <canvas id="myChart7"></canvas>
            <h1>ناصر السبيعي</h1>
        </div>
       <div class="col-sm-12 col-lg-4">
            <canvas id="myChart8"></canvas>
            <h1>نايف صقر</h1>
        </div>
        <!-- -->
        <div class="col-sm-12 col-lg-4"></div>
        <div class="col-sm-12 col-lg-4"></div>
        <div class="col-sm-12 col-lg-4"></div>
        <div class="col-sm-12 col-lg-4"></div>
        <div class="col-sm-12 col-lg-4"><h1 style="margin:5rem 0;">الأعضاء ضمن لجنة الفرز </h1></div>
        <div class="col-sm-12 col-lg-4"></div>
        <hr>
        <!-- -->
       <div class="col-sm-12 col-lg-4">
            <canvas id="myChart"></canvas>
            <h1>بشائر</h1>
        </div>
       <div class="col-sm-12 col-lg-4">
            <canvas id="myChart2"></canvas>
            <h1>ممدوح</h1>
        </div>
       <div class="col-sm-12 col-lg-4">
            <canvas id="myChart3"></canvas>
            <h1>مشعل</h1>
        </div>
        <?php endif; ?>
    </div>
    <div id="editor"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>

<?php if(Auth::user()->type == 1 || Auth::user()->type == 3): ?>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.5.3/jspdf.min.js"></script>
    <script type="text/javascript" src="https://html2canvas.hertzen.com/dist/html2canvas.js"></script>
    <script>
    document.getElementById('export-report').addEventListener("click",function(){
        CreatePDFfromHTML();
    });
    
    function CreatePDFfromHTML() {
        var HTML_Width = $("#canvas_image").width();
        var HTML_Height = $("#canvas_image").height();
        var top_left_margin = 15;
        var PDF_Width = HTML_Width + (top_left_margin * 2);
        var PDF_Height = (PDF_Width * 1.5) + (top_left_margin * 2);
        var canvas_image_width = HTML_Width;
        var canvas_image_height = HTML_Height;
    
        var totalPDFPages = Math.ceil(HTML_Height / PDF_Height) - 1;
    
        html2canvas($("#canvas_image")[0],{allowTaint:true}).then(function (canvas) {
            canvas.getContext('2d');
            var imgData = canvas.toDataURL("image/jpeg", 1.0);
            var pdf = new jsPDF('p', 'pt', [PDF_Width, PDF_Height]);
            pdf.addImage(imgData, 'JPG', top_left_margin, top_left_margin, canvas_image_width, canvas_image_height);
            for (var i = 1; i <= totalPDFPages; i++) { 
                pdf.addPage(PDF_Width, PDF_Height);
                pdf.addImage(imgData, 'JPG', top_left_margin, -(PDF_Height*i)+(top_left_margin*4),canvas_image_width,canvas_image_height);
            }
            pdf.save("Report.pdf");
        });
    }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        var bshaer = <?php echo json_encode($data['bshaer']); ?>;
        var mmdoh = <?php echo json_encode($data['mmdoh']); ?>;
        var mshael = <?php echo json_encode($data['mshael']); ?>;
        const data = {
          labels: [
            'بحاجة تقييم',
            'تم التقييم',
          ],
          datasets: [{
            label: 'بشائر',
            data: bshaer,
            backgroundColor: [
              'rgb(255, 99, 132)',
              'rgb(54, 162, 235)'
            ],
            hoverOffset: 4
          }]
        };
        
        const data2 = {
          labels: [
            'بحاجة تقييم',
            'تم التقييم',
          ],
          datasets: [{
            label: 'ممدوح',
            data: mmdoh,
            backgroundColor: [
              'rgb(255, 99, 132)',
              'rgb(54, 162, 235)'
            ],
            hoverOffset: 4
          }]
        };
        
        const data3 = {
          labels: [
            'بحاجة تقييم',
            'تم التقييم',
          ],
          datasets: [{
            label: 'مشعل',
            data: mshael,
            backgroundColor: [
              'rgb(255, 99, 132)',
              'rgb(54, 162, 235)'
            ],
            hoverOffset: 4
          }]
        };
        
        const config = {
          type: 'doughnut',
          data: data,
        };
        
        const config2 = {
          type: 'doughnut',
          data: data2,
        };
        
        const config3 = {
          type: 'doughnut',
          data: data3,
        };
        
          const myChart = new Chart(
            document.getElementById('myChart'),
            config
          );
          
            const myChart2 = new Chart(
            document.getElementById('myChart2'),
            config2
          );
          
            const myChart3 = new Chart(
            document.getElementById('myChart3'),
            config3
          );
    </script>
    <script>
        var khaild = <?php echo json_encode($data['khalid']); ?>;
        var nasser = <?php echo json_encode($data['nasser']); ?>;
        var naif = <?php echo json_encode($data['naif']); ?>;
        
        
        const data6 = {
          labels: [
            'بحاجة تقييم',
            'تم التقييم',
          ],
          datasets: [{
            label: 'خالد',
            data: khaild,
            backgroundColor: [
              'rgb(67, 45, 185)',
              'rgb(70, 170, 70)'
            ],
            hoverOffset: 4
          }]
        };
        
        const data7 = {
          labels: [
            'بحاجة تقييم',
            'تم التقييم',
          ],
          datasets: [{
            label: 'ناصر',
            data: nasser,
            backgroundColor: [
              'rgb(67, 45, 185)',
              'rgb(70, 170, 70)'
            ],
            hoverOffset: 4
          }]
        };
        
        const data8 = {
          labels: [
            'بحاجة تقييم',
            'تم التقييم',
          ],
          datasets: [{
            label: 'نايف',
            data: naif,
            backgroundColor: [
              'rgb(67, 45, 185)',
              'rgb(70, 170, 70)'
            ],
            hoverOffset: 4
          }]
        };
        
        const config6 = {
          type: 'doughnut',
          data: data6,
        };
        
        const config7 = {
          type: 'doughnut',
          data: data7,
        };
        
        const config8 = {
          type: 'doughnut',
          data: data8,
        };
        
        
          const myChart6 = new Chart(
            document.getElementById('myChart6'),
            config6
          );
          
            const myChart7 = new Chart(
            document.getElementById('myChart7'),
            config7
          );
          
            const myChart8 = new Chart(
            document.getElementById('myChart8'),
            config8
          );
        
    </script>
    
    <script>
        var countries = <?php echo json_encode($data['countries']); ?>;
        
        
        const dataCountries = {
          labels: [
            'المملكة العربية السعودية',
            'سوريا',
            'مصر',
            'الكويت',
            'قطر',
            'سلطنة عمان',
            'البحرين',
            'الأردن',
            'العراق',
            'ليبيا',
            'الجزائر',
            'فلسطين'
          ],
          datasets: [{
            label: 'المشاركين في برنامج شاعر الراية',
            data: countries,
            backgroundColor: [
              'rgba(2, 76, 1, 1)',
              'rgba(210, 8, 8, 1)',
              'rgba(255, 205, 86, 1)',
              'rgba(75, 192, 192, 1)',
              'rgba(54, 162, 235, 1)',
              'rgba(153, 102, 255,1)',
              'rgba(201, 203, 207,1)',
               'rgba(255, 99, 132, 1)',
              'rgba(255, 159, 64, 1)',
              'rgba(255, 205, 86, 1)',
              'rgba(75, 192, 192, 1)',
              'rgba(54, 162, 235, 1)',
              
            ],
            borderColor: [
              'rgb(2, 76, 1)',
              'rgb(210, 8, 8)',
              'rgb(255, 205, 86)',
              'rgb(75, 192, 192)',
              'rgb(54, 162, 235)',
              'rgb(153, 102, 255)',
              'rgb(201, 203, 207)',
              'rgb(255, 99, 132)',
              'rgb(255, 159, 64)',
              'rgb(255, 205, 86)',
              'rgb(75, 192, 192)',
              'rgb(54, 162, 235)',
            ],
             borderWidth: 1
          }]
        };
        
        const configCountries = {
          type: 'doughnut',
          data: dataCountries,
          options: {
            // scales: {
            //   y: {
            //     title: {
            //       display: true,
            //       text: ''
            //     },
            //     min: 0,
            //     max: 350,
            //     ticks: {
            //       // forces step size to be 50 units
            //       stepSize: 20
            //     }
            //   }
            // },
            plugins: {
                legend: {
                  display: false
                }
              }
          },
        };
        
        const myChartCountries = new Chart(
            document.getElementById('myChartCountries'),
            configCountries
          );
    </script>
    <script>
        var genderCount = <?php echo json_encode($data['gender']); ?>;
        
        
        const dataGender = {
          labels: [
            'ذكور',
            'إناث',
          ],
          datasets: [{
            label: 'الجنس',
            data: genderCount,
            backgroundColor: [
            'rgb(54, 162, 235)',
            'rgb(255, 99, 132)',
            ],
            hoverOffset: 4
          }]
        };
        
        const configGender = {
          type: 'doughnut',
          data: dataGender,
          options: {
              plugins: {
                legend: {
                  display: false
                }
              }
            }
        };
        
        
          const myChartGender = new Chart(
            document.getElementById('myChartGender'),
            configGender,
          );
    </script>
    <script>
        var FinalResult = <?php echo json_encode($data['FinalResult']); ?>;
        
        
        const dataAllCounts = {
          labels: [
            'المتقدمين',
            'المرشحين',
            'المشاركين'
          ],
          datasets: [{
            label: 'العدد',
            data: [354,97,FinalResult],
            backgroundColor: [
              'rgba(86, 4, 89, 1)',
              'rgba(4, 3, 92, 1)',
              'rgba(255, 205, 86, 1)'
              
            ],
            borderColor: [
              'rgb(86, 4, 89)',
              'rgb(4, 3, 92)',
              'rgb(255, 205, 86)'
            ],
             borderWidth: 1
          }]
        };
        
        const configAllCounts = {
          type: 'bar',
          data: dataAllCounts,
          options: {
            scales: {
              y: {
                title: {
                  display: true,
                  text: ''
                },
                min: 0,
                max: 350,
                ticks: {
                  // forces step size to be 50 units
                  stepSize: 20
                }
              }
            },
            plugins: {
                legend: {
                  display: false
                }
              }
          },
        };
        
        const myChartAllCounts = new Chart(
            document.getElementById('myChartAllCounts'),
            configAllCounts
          );
    </script>
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.appp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alrayapoet/public_html/vision/resources/views/home.blade.php ENDPATH**/ ?>