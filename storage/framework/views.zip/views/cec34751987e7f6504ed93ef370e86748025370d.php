
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> شاعر الرؤية</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Amiri&family=Cairo:wght@200&family=Montserrat:wght@100&family=Poppins:wght@400;500;600&family=Roboto+Serif:wght@100&display=swap" rel="stylesheet">
    <link href="//db.onlinewebfonts.com/c/593331e50d21b6415d53fc7c416b5b8e?family=FrutigerLTArabic-75Black" rel="stylesheet" type="text/css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/css/bootstrap-select.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.18/css/bootstrap-select.min.css" integrity="sha512-ARJR74swou2y0Q2V9k0GbzQ/5vJ2RBSoCWokg4zkfM29Fb3vZEQyv0iWBMW/yvKgyHSR/7D64pFMmU8nYmbRkg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.css" />
    <link href="//db.onlinewebfonts.com/c/8e84296a186f1941f28261b7dc98a78b?family=FrutigerLTArabic-45Light" rel="stylesheet" type="text/css"/>
    <link rel="stylesheet" href="public/assets/register/css/style.css">
    <link href="https://unpkg.com/filepond/dist/filepond.css" rel="stylesheet" />
    <style>
        fieldset.filepond--file-wrapper{
            background: #b79045  !important;
        }
        [data-filepond-item-state='processing-complete'] .filepond--action-revert-item-processing svg,.filepond--file-action-button.filepond--file-action-button svg  {
            margin-top: -.5rem !important;
        }
        section.header {
    background: #b79045;
            
        }
        #progressbar li.active:before, #progressbar li.active:after {
    background: #b79045;
}


.justify-content-center {
    
    
    background-color: #b79045;
}

#msform .action-button {
    width: 100px;
    background: #b79045;}
    
    .labelclass {
    float: right;  
  }
  .form-group label:before{
      
      float: right;
  }
  body{
    background-color: #b79045;  
  }

    </style>
</head>
<body>


<section class="header" >
    <h1>للمشاركة في البرنامج</h1>
</section>

    <!-- MultiStep Form -->
<div class="container-fluid" id="grad1">
    <div class="row justify-content-center mt-0">
        <div class="col-11 col-sm-9 col-md-7 col-lg-9 text-center p-0 mt-3 mb-2">
            <div class="card px-0 pb-0 mt-3 mb-3">
                <!--<img class="img-line" src="public/w-9.png" alt="">-->
                <div class="row">
                    <div class="col-md-12 mx-0">
                        <form id="msform" action="<?php echo e(url()->current()); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <ul id="progressbar">
                                <li id="payment"><strong></strong>حدثنا عنك </li>
                                <li id="account"><strong></strong>تحميل مشاركتك </li>
                                <li class="active" id="personal">معلوماتك الشخصية </li>

                            </ul> <!-- fieldsets -->
                            <fieldset data-set="1">
                                <div class="form-card">
                                    <h2 style="text-align:end" class="fs-title"> معلوماتك الشخصية</h2>
                                    <br>
                                    <div class="row box">
                                        <div class="col-md-6 div1">
                                            <label for="member" class="float-right"> البريد الالكتروني </label>
                                            <input dir="rtl" type="email" required id="email" name="email" placeholder="" />
                                            <span class="invalidEmailMSG" style="position:absolute;color:red">*</span>
                                        </div>
                                        <div class="col-md-6 div2">
                                            <label for="member" class="float-right">الاسم الكامل </label>
                                            <input dir="rtl" type="text" id="name" name="name" placeholder="" />
                                        </div>
                                    </div>
                                    <div class="row">

                                    <div class="col-md-6  mobile-clas">
                                         <label for="mobile" class="float-right">رقم الجوال</label>
                                 <br>

                                            <input dir="rtl" type="number" pattern="\d*" maxlength="9" id="mobile" name="mobile" placeholder="" />
                                        </div>

                                        
                                        <div class="col-md-6">
                                            <label for="gender" class="float-right">الجنس</label>
                                    <select style="" name="gender" id="gender" dir="rtl" class="form-control">
                                            <option value="ذكر">
                                                 ذكر </option>
                                            <option value="أنثى ">
                                                أنثى 
                                            </option>
                                    </select>
                                        </div>
                                    </div><br>
                                    <div class="row">
                                        <div class="col-md-6">
                                        
                                    
                                      <label for="city" class="float-right">الدولة المقيم فيها  </label>
                                   <select style="" type="text" id="city" name="city" dir="rtl"  class="form-control" required>
                                        <option value="Saudi Arabia">Saudi Arabia</option>
                                        <option value="Afganistan">Afghanistan</option>
                                        <option value="Albania">Albania</option>
                                        <option value="Algeria">Algeria</option>
                                        <option value="American Samoa">American Samoa</option>
                                        <option value="Andorra">Andorra</option>
                                        <option value="Angola">Angola</option>
                                        <option value="Anguilla">Anguilla</option>
                                        <option value="Antigua & Barbuda">Antigua & Barbuda</option>
                                        <option value="Argentina">Argentina</option>
                                        <option value="Armenia">Armenia</option>
                                        <option value="Aruba">Aruba</option>
                                        <option value="Australia">Australia</option>
                                        <option value="Austria">Austria</option>
                                        <option value="Azerbaijan">Azerbaijan</option>
                                        <option value="Bahamas">Bahamas</option>
                                        <option value="Bahrain">Bahrain</option>
                                        <option value="Bangladesh">Bangladesh</option>
                                        <option value="Barbados">Barbados</option>
                                        <option value="Belarus">Belarus</option>
                                        <option value="Belgium">Belgium</option>
                                        <option value="Belize">Belize</option>
                                        <option value="Benin">Benin</option>
                                        <option value="Bermuda">Bermuda</option>
                                        <option value="Bhutan">Bhutan</option>
                                        <option value="Bolivia">Bolivia</option>
                                        <option value="Bonaire">Bonaire</option>
                                        <option value="Bosnia & Herzegovina">Bosnia & Herzegovina</option>
                                        <option value="Botswana">Botswana</option>
                                        <option value="Brazil">Brazil</option>
                                        <option value="British Indian Ocean Ter">British Indian Ocean Ter</option>
                                        <option value="Brunei">Brunei</option>
                                        <option value="Bulgaria">Bulgaria</option>
                                        <option value="Burkina Faso">Burkina Faso</option>
                                        <option value="Burundi">Burundi</option>
                                        <option value="Cambodia">Cambodia</option>
                                        <option value="Cameroon">Cameroon</option>
                                        <option value="Canada">Canada</option>
                                        <option value="Canary Islands">Canary Islands</option>
                                        <option value="Cape Verde">Cape Verde</option>
                                        <option value="Cayman Islands">Cayman Islands</option>
                                        <option value="Central African Republic">Central African Republic</option>
                                        <option value="Chad">Chad</option>
                                        <option value="Channel Islands">Channel Islands</option>
                                        <option value="Chile">Chile</option>
                                        <option value="China">China</option>
                                        <option value="Christmas Island">Christmas Island</option>
                                        <option value="Cocos Island">Cocos Island</option>
                                        <option value="Colombia">Colombia</option>
                                        <option value="Comoros">Comoros</option>
                                        <option value="Congo">Congo</option>
                                        <option value="Cook Islands">Cook Islands</option>
                                        <option value="Costa Rica">Costa Rica</option>
                                        <option value="Cote DIvoire">Cote DIvoire</option>
                                        <option value="Croatia">Croatia</option>
                                        <option value="Cuba">Cuba</option>
                                        <option value="Curaco">Curacao</option>
                                        <option value="Cyprus">Cyprus</option>
                                        <option value="Czech Republic">Czech Republic</option>
                                        <option value="Denmark">Denmark</option>
                                        <option value="Djibouti">Djibouti</option>
                                        <option value="Dominica">Dominica</option>
                                        <option value="Dominican Republic">Dominican Republic</option>
                                        <option value="East Timor">East Timor</option>
                                        <option value="Ecuador">Ecuador</option>
                                        <option value="Egypt">Egypt</option>
                                        <option value="El Salvador">El Salvador</option>
                                        <option value="Equatorial Guinea">Equatorial Guinea</option>
                                        <option value="Eritrea">Eritrea</option>
                                        <option value="Estonia">Estonia</option>
                                        <option value="Ethiopia">Ethiopia</option>
                                        <option value="Falkland Islands">Falkland Islands</option>
                                        <option value="Faroe Islands">Faroe Islands</option>
                                        <option value="Fiji">Fiji</option>
                                        <option value="Finland">Finland</option>
                                        <option value="France">France</option>
                                        <option value="French Guiana">French Guiana</option>
                                        <option value="French Polynesia">French Polynesia</option>
                                        <option value="French Southern Ter">French Southern Ter</option>
                                        <option value="Gabon">Gabon</option>
                                        <option value="Gambia">Gambia</option>
                                        <option value="Georgia">Georgia</option>
                                        <option value="Germany">Germany</option>
                                        <option value="Ghana">Ghana</option>
                                        <option value="Gibraltar">Gibraltar</option>
                                        <option value="Great Britain">Great Britain</option>
                                        <option value="Greece">Greece</option>
                                        <option value="Greenland">Greenland</option>
                                        <option value="Grenada">Grenada</option>
                                        <option value="Guadeloupe">Guadeloupe</option>
                                        <option value="Guam">Guam</option>
                                        <option value="Guatemala">Guatemala</option>
                                        <option value="Guinea">Guinea</option>
                                        <option value="Guyana">Guyana</option>
                                        <option value="Haiti">Haiti</option>
                                        <option value="Hawaii">Hawaii</option>
                                        <option value="Honduras">Honduras</option>
                                        <option value="Hong Kong">Hong Kong</option>
                                        <option value="Hungary">Hungary</option>
                                        <option value="Iceland">Iceland</option>
                                        <option value="Indonesia">Indonesia</option>
                                        <option value="India">India</option>
                                        <option value="Iran">Iran</option>
                                        <option value="Iraq">Iraq</option>
                                        <option value="Ireland">Ireland</option>
                                        <option value="Isle of Man">Isle of Man</option>
                                        <option value="Israel">Israel</option>
                                        <option value="Italy">Italy</option>
                                        <option value="Jamaica">Jamaica</option>
                                        <option value="Japan">Japan</option>
                                        <option value="Jordan">Jordan</option>
                                        <option value="Kazakhstan">Kazakhstan</option>
                                        <option value="Kenya">Kenya</option>
                                        <option value="Kiribati">Kiribati</option>
                                        <option value="Korea North">Korea North</option>
                                        <option value="Korea Sout">Korea South</option>
                                        <option value="Kuwait">Kuwait</option>
                                        <option value="Kyrgyzstan">Kyrgyzstan</option>
                                        <option value="Laos">Laos</option>
                                        <option value="Latvia">Latvia</option>
                                        <option value="Lebanon">Lebanon</option>
                                        <option value="Lesotho">Lesotho</option>
                                        <option value="Liberia">Liberia</option>
                                        <option value="Libya">Libya</option>
                                        <option value="Liechtenstein">Liechtenstein</option>
                                        <option value="Lithuania">Lithuania</option>
                                        <option value="Luxembourg">Luxembourg</option>
                                        <option value="Macau">Macau</option>
                                        <option value="Macedonia">Macedonia</option>
                                        <option value="Madagascar">Madagascar</option>
                                        <option value="Malaysia">Malaysia</option>
                                        <option value="Malawi">Malawi</option>
                                        <option value="Maldives">Maldives</option>
                                        <option value="Mali">Mali</option>
                                        <option value="Malta">Malta</option>
                                        <option value="Marshall Islands">Marshall Islands</option>
                                        <option value="Martinique">Martinique</option>
                                        <option value="Mauritania">Mauritania</option>
                                        <option value="Mauritius">Mauritius</option>
                                        <option value="Mayotte">Mayotte</option>
                                        <option value="Mexico">Mexico</option>
                                        <option value="Midway Islands">Midway Islands</option>
                                        <option value="Moldova">Moldova</option>
                                        <option value="Monaco">Monaco</option>
                                        <option value="Mongolia">Mongolia</option>
                                        <option value="Montserrat">Montserrat</option>
                                        <option value="Morocco">Morocco</option>
                                        <option value="Mozambique">Mozambique</option>
                                        <option value="Myanmar">Myanmar</option>
                                        <option value="Nambia">Nambia</option>
                                        <option value="Nauru">Nauru</option>
                                        <option value="Nepal">Nepal</option>
                                        <option value="Netherland Antilles">Netherland Antilles</option>
                                        <option value="Netherlands">Netherlands (Holland, Europe)</option>
                                        <option value="Nevis">Nevis</option>
                                        <option value="New Caledonia">New Caledonia</option>
                                        <option value="New Zealand">New Zealand</option>
                                        <option value="Nicaragua">Nicaragua</option>
                                        <option value="Niger">Niger</option>
                                        <option value="Nigeria">Nigeria</option>
                                        <option value="Niue">Niue</option>
                                        <option value="Norfolk Island">Norfolk Island</option>
                                        <option value="Norway">Norway</option>
                                        <option value="Oman">Oman</option>
                                        <option value="Pakistan">Pakistan</option>
                                        <option value="Palau Island">Palau Island</option>
                                        <option value="Palestine">Palestine</option>
                                        <option value="Panama">Panama</option>
                                        <option value="Papua New Guinea">Papua New Guinea</option>
                                        <option value="Paraguay">Paraguay</option>
                                        <option value="Peru">Peru</option>
                                        <option value="Phillipines">Philippines</option>
                                        <option value="Pitcairn Island">Pitcairn Island</option>
                                        <option value="Poland">Poland</option>
                                        <option value="Portugal">Portugal</option>
                                        <option value="Puerto Rico">Puerto Rico</option>
                                        <option value="Qatar">Qatar</option>
                                        <option value="Republic of Montenegro">Republic of Montenegro</option>
                                        <option value="Republic of Serbia">Republic of Serbia</option>
                                        <option value="Reunion">Reunion</option>
                                        <option value="Romania">Romania</option>
                                        <option value="Russia">Russia</option>
                                        <option value="Rwanda">Rwanda</option>
                                        <option value="St Barthelemy">St Barthelemy</option>
                                        <option value="St Eustatius">St Eustatius</option>
                                        <option value="St Helena">St Helena</option>
                                        <option value="St Kitts-Nevis">St Kitts-Nevis</option>
                                        <option value="St Lucia">St Lucia</option>
                                        <option value="St Maarten">St Maarten</option>
                                        <option value="St Pierre & Miquelon">St Pierre & Miquelon</option>
                                        <option value="St Vincent & Grenadines">St Vincent & Grenadines</option>
                                        <option value="Saipan">Saipan</option>
                                        <option value="Samoa">Samoa</option>
                                        <option value="Samoa American">Samoa American</option>
                                        <option value="San Marino">San Marino</option>
                                        <option value="Sao Tome & Principe">Sao Tome & Principe</option>
                                        <option value="Senegal">Senegal</option>
                                        <option value="Seychelles">Seychelles</option>
                                        <option value="Sierra Leone">Sierra Leone</option>
                                        <option value="Singapore">Singapore</option>
                                        <option value="Slovakia">Slovakia</option>
                                        <option value="Slovenia">Slovenia</option>
                                        <option value="Solomon Islands">Solomon Islands</option>
                                        <option value="Somalia">Somalia</option>
                                        <option value="South Africa">South Africa</option>
                                        <option value="Spain">Spain</option>
                                        <option value="Sri Lanka">Sri Lanka</option>
                                        <option value="Sudan">Sudan</option>
                                        <option value="Suriname">Suriname</option>
                                        <option value="Swaziland">Swaziland</option>
                                        <option value="Sweden">Sweden</option>
                                        <option value="Switzerland">Switzerland</option>
                                        <option value="Syria">Syria</option>
                                        <option value="Tahiti">Tahiti</option>
                                        <option value="Taiwan">Taiwan</option>
                                        <option value="Tajikistan">Tajikistan</option>
                                        <option value="Tanzania">Tanzania</option>
                                        <option value="Thailand">Thailand</option>
                                        <option value="Togo">Togo</option>
                                        <option value="Tokelau">Tokelau</option>
                                        <option value="Tonga">Tonga</option>
                                        <option value="Trinidad & Tobago">Trinidad & Tobago</option>
                                        <option value="Tunisia">Tunisia</option>
                                        <option value="Turkey">Turkey</option>
                                        <option value="Turkmenistan">Turkmenistan</option>
                                        <option value="Turks & Caicos Is">Turks & Caicos Is</option>
                                        <option value="Tuvalu">Tuvalu</option>
                                        <option value="Uganda">Uganda</option>
                                        <option value="United Kingdom">United Kingdom</option>
                                        <option value="Ukraine">Ukraine</option>
                                        <option value="United Arab Erimates">United Arab Emirates</option>
                                        <option value="United States of America">United States of America</option>
                                        <option value="Uraguay">Uruguay</option>
                                        <option value="Uzbekistan">Uzbekistan</option>
                                        <option value="Vanuatu">Vanuatu</option>
                                        <option value="Vatican City State">Vatican City State</option>
                                        <option value="Venezuela">Venezuela</option>
                                        <option value="Vietnam">Vietnam</option>
                                        <option value="Virgin Islands (Brit)">Virgin Islands (Brit)</option>
                                        <option value="Virgin Islands (USA)">Virgin Islands (USA)</option>
                                        <option value="Wake Island">Wake Island</option>
                                        <option value="Wallis & Futana Is">Wallis & Futana Is</option>
                                        <option value="Yemen">Yemen</option>
                                        <option value="Zaire">Zaire</option>
                                        <option value="Zambia">Zambia</option>
                                        <option value="Zimbabwe">Zimbabwe</option>
                                    </select><br>
                                    
                                    
                                    
                                    </div>
                                        <div class="col-md-6">
                                            <label for="member" class="float-right">الجنسية</label><br>
                                            <select id="nationality" name="nationality" dir="rtl" class="form-control">
                                              <option value="">-- select one --</option>
                                              <option value="afghan">Afghan</option>
                                              <option value="albanian">Albanian</option>
                                              <option value="algerian">Algerian</option>
                                              <option value="american">American</option>
                                              <option value="andorran">Andorran</option>
                                              <option value="angolan">Angolan</option>
                                              <option value="antiguans">Antiguans</option>
                                              <option value="argentinean">Argentinean</option>
                                              <option value="armenian">Armenian</option>
                                              <option value="australian">Australian</option>
                                              <option value="austrian">Austrian</option>
                                              <option value="azerbaijani">Azerbaijani</option>
                                              <option value="bahamian">Bahamian</option>
                                              <option value="bahraini">Bahraini</option>
                                              <option value="bangladeshi">Bangladeshi</option>
                                              <option value="barbadian">Barbadian</option>
                                              <option value="barbudans">Barbudans</option>
                                              <option value="batswana">Batswana</option>
                                              <option value="belarusian">Belarusian</option>
                                              <option value="belgian">Belgian</option>
                                              <option value="belizean">Belizean</option>
                                              <option value="beninese">Beninese</option>
                                              <option value="bhutanese">Bhutanese</option>
                                              <option value="bolivian">Bolivian</option>
                                              <option value="bosnian">Bosnian</option>
                                              <option value="brazilian">Brazilian</option>
                                              <option value="british">British</option>
                                              <option value="bruneian">Bruneian</option>
                                              <option value="bulgarian">Bulgarian</option>
                                              <option value="burkinabe">Burkinabe</option>
                                              <option value="burmese">Burmese</option>
                                              <option value="burundian">Burundian</option>
                                              <option value="cambodian">Cambodian</option>
                                              <option value="cameroonian">Cameroonian</option>
                                              <option value="canadian">Canadian</option>
                                              <option value="cape verdean">Cape Verdean</option>
                                              <option value="central african">Central African</option>
                                              <option value="chadian">Chadian</option>
                                              <option value="chilean">Chilean</option>
                                              <option value="chinese">Chinese</option>
                                              <option value="colombian">Colombian</option>
                                              <option value="comoran">Comoran</option>
                                              <option value="congolese">Congolese</option>
                                              <option value="costa rican">Costa Rican</option>
                                              <option value="croatian">Croatian</option>
                                              <option value="cuban">Cuban</option>
                                              <option value="cypriot">Cypriot</option>
                                              <option value="czech">Czech</option>
                                              <option value="danish">Danish</option>
                                              <option value="djibouti">Djibouti</option>
                                              <option value="dominican">Dominican</option>
                                              <option value="dutch">Dutch</option>
                                              <option value="east timorese">East Timorese</option>
                                              <option value="ecuadorean">Ecuadorean</option>
                                              <option value="egyptian">Egyptian</option>
                                              <option value="emirian">Emirian</option>
                                              <option value="equatorial guinean">Equatorial Guinean</option>
                                              <option value="eritrean">Eritrean</option>
                                              <option value="estonian">Estonian</option>
                                              <option value="ethiopian">Ethiopian</option>
                                              <option value="fijian">Fijian</option>
                                              <option value="filipino">Filipino</option>
                                              <option value="finnish">Finnish</option>
                                              <option value="french">French</option>
                                              <option value="gabonese">Gabonese</option>
                                              <option value="gambian">Gambian</option>
                                              <option value="georgian">Georgian</option>
                                              <option value="german">German</option>
                                              <option value="ghanaian">Ghanaian</option>
                                              <option value="greek">Greek</option>
                                              <option value="grenadian">Grenadian</option>
                                              <option value="guatemalan">Guatemalan</option>
                                              <option value="guinea-bissauan">Guinea-Bissauan</option>
                                              <option value="guinean">Guinean</option>
                                              <option value="guyanese">Guyanese</option>
                                              <option value="haitian">Haitian</option>
                                              <option value="herzegovinian">Herzegovinian</option>
                                              <option value="honduran">Honduran</option>
                                              <option value="hungarian">Hungarian</option>
                                              <option value="icelander">Icelander</option>
                                              <option value="indian">Indian</option>
                                              <option value="indonesian">Indonesian</option>
                                              <option value="iranian">Iranian</option>
                                              <option value="iraqi">Iraqi</option>
                                              <option value="irish">Irish</option>
                                              <option value="israeli">Israeli</option>
                                              <option value="italian">Italian</option>
                                              <option value="ivorian">Ivorian</option>
                                              <option value="jamaican">Jamaican</option>
                                              <option value="japanese">Japanese</option>
                                              <option value="jordanian">Jordanian</option>
                                              <option value="kazakhstani">Kazakhstani</option>
                                              <option value="kenyan">Kenyan</option>
                                              <option value="kittian and nevisian">Kittian and Nevisian</option>
                                              <option value="kuwaiti">Kuwaiti</option>
                                              <option value="kyrgyz">Kyrgyz</option>
                                              <option value="laotian">Laotian</option>
                                              <option value="latvian">Latvian</option>
                                              <option value="lebanese">Lebanese</option>
                                              <option value="liberian">Liberian</option>
                                              <option value="libyan">Libyan</option>
                                              <option value="liechtensteiner">Liechtensteiner</option>
                                              <option value="lithuanian">Lithuanian</option>
                                              <option value="luxembourger">Luxembourger</option>
                                              <option value="macedonian">Macedonian</option>
                                              <option value="malagasy">Malagasy</option>
                                              <option value="malawian">Malawian</option>
                                              <option value="malaysian">Malaysian</option>
                                              <option value="maldivan">Maldivan</option>
                                              <option value="malian">Malian</option>
                                              <option value="maltese">Maltese</option>
                                              <option value="marshallese">Marshallese</option>
                                              <option value="mauritanian">Mauritanian</option>
                                              <option value="mauritian">Mauritian</option>
                                              <option value="mexican">Mexican</option>
                                              <option value="micronesian">Micronesian</option>
                                              <option value="moldovan">Moldovan</option>
                                              <option value="monacan">Monacan</option>
                                              <option value="mongolian">Mongolian</option>
                                              <option value="moroccan">Moroccan</option>
                                              <option value="mosotho">Mosotho</option>
                                              <option value="motswana">Motswana</option>
                                              <option value="mozambican">Mozambican</option>
                                              <option value="namibian">Namibian</option>
                                              <option value="nauruan">Nauruan</option>
                                              <option value="nepalese">Nepalese</option>
                                              <option value="new zealander">New Zealander</option>
                                              <option value="ni-vanuatu">Ni-Vanuatu</option>
                                              <option value="nicaraguan">Nicaraguan</option>
                                              <option value="nigerien">Nigerien</option>
                                              <option value="north korean">North Korean</option>
                                              <option value="northern irish">Northern Irish</option>
                                              <option value="norwegian">Norwegian</option>
                                              <option value="omani">Omani</option>
                                              <option value="pakistani">Pakistani</option>
                                              <option value="palauan">Palauan</option>
                                              <option value="panamanian">Panamanian</option>
                                              <option value="papua new guinean">Papua New Guinean</option>
                                              <option value="paraguayan">Paraguayan</option>
                                              <option value="peruvian">Peruvian</option>
                                              <option value="polish">Polish</option>
                                              <option value="portuguese">Portuguese</option>
                                              <option value="qatari">Qatari</option>
                                              <option value="romanian">Romanian</option>
                                              <option value="russian">Russian</option>
                                              <option value="rwandan">Rwandan</option>
                                              <option value="saint lucian">Saint Lucian</option>
                                              <option value="salvadoran">Salvadoran</option>
                                              <option value="samoan">Samoan</option>
                                              <option value="san marinese">San Marinese</option>
                                              <option value="sao tomean">Sao Tomean</option>
                                              <option value="saudi" selected>Saudi</option>
                                              <option value="scottish">Scottish</option>
                                              <option value="senegalese">Senegalese</option>
                                              <option value="serbian">Serbian</option>
                                              <option value="seychellois">Seychellois</option>
                                              <option value="sierra leonean">Sierra Leonean</option>
                                              <option value="singaporean">Singaporean</option>
                                              <option value="slovakian">Slovakian</option>
                                              <option value="slovenian">Slovenian</option>
                                              <option value="solomon islander">Solomon Islander</option>
                                              <option value="somali">Somali</option>
                                              <option value="south african">South African</option>
                                              <option value="south korean">South Korean</option>
                                              <option value="spanish">Spanish</option>
                                              <option value="sri lankan">Sri Lankan</option>
                                              <option value="sudanese">Sudanese</option>
                                              <option value="surinamer">Surinamer</option>
                                              <option value="swazi">Swazi</option>
                                              <option value="swedish">Swedish</option>
                                              <option value="swiss">Swiss</option>
                                              <option value="syrian">Syrian</option>
                                              <option value="taiwanese">Taiwanese</option>
                                              <option value="tajik">Tajik</option>
                                              <option value="tanzanian">Tanzanian</option>
                                              <option value="thai">Thai</option>
                                              <option value="togolese">Togolese</option>
                                              <option value="tongan">Tongan</option>
                                              <option value="trinidadian or tobagonian">Trinidadian or Tobagonian</option>
                                              <option value="tunisian">Tunisian</option>
                                              <option value="turkish">Turkish</option>
                                              <option value="tuvaluan">Tuvaluan</option>
                                              <option value="ugandan">Ugandan</option>
                                              <option value="ukrainian">Ukrainian</option>
                                              <option value="uruguayan">Uruguayan</option>
                                              <option value="uzbekistani">Uzbekistani</option>
                                              <option value="venezuelan">Venezuelan</option>
                                              <option value="vietnamese">Vietnamese</option>
                                              <option value="welsh">Welsh</option>
                                              <option value="yemenite">Yemenite</option>
                                              <option value="zambian">Zambian</option>
                                              <option value="zimbabwean">Zimbabwean</option>
                                            </select><br>
                                        </div>
                                    </div>

                                        <div  dir="rtl" class="row">
                                            <div class="col-lg-12">
                                            <label dir="rtl"  for="age" class="float-right">تاريخ الميلاد </label>
                                            
                                            <select style="" name="birthdate_type" id="birthdate_type" dir="rtl" class="form-control">
                                            <option value="هجري">
                                                 هجري </option>
                                            <option value="ميلادي">
                                                ميلادي 
                                            </option>
                                    </select>
                                            
                                           </div> <br><br>
    <div class=" col-md-4">
        <br>
       <label class="labelclass" for="inputState">السنة</label>
      <input dir="rtl" type="number" id="year" name="year" placeholder=" " />
    </div>
    <div class=" col-md-4">
        <br>
      <label class="labelclass" for="inputState">الشهر</label>
       <input dir="rtl" type="number" id="month" name="month" placeholder=" " />
    </div>
    <div class=" col-md-4">
        <br>
      <label class="labelclass"  for="inputZip">اليوم</label>
       <input dir="rtl" type="number" id="day" name="day" placeholder=" " />
    </div>
  </div>
                                   
                                  
                                    
                                <div class="row">
                                    <div class="col-lg-12">
                                        <label for="hobbies" class="float-right">حسابات التواصل الاجتماعي</label>
                                        <br><br>
                                         <div class="form-card" style="text-align: end;">
                                        <div class="memberSelect" style="text-align: end;">
                                        <label for="member">فيسبوك </label>
                                            <input dir="rtl" type="text" class="form-control" name="facebook" id="facebook_account">
                                        </div>
                                        <div class="memberSelect" style="text-align: end;">
                                        <label for="member">انستغرام </label>
                                            <input dir="rtl" type="text" class="form-control" name="instagram" id="instagram_account">
                                        </div>
                                        <div class="memberSelect" style="text-align: end;">
                                        <label for="member">تويتر </label>
                                            <input dir="rtl" type="text" class="form-control" name="twitter" id="twitter_account">
                                        </div>
                                        </div>
                                    </div>
                                </div>    
                                    
                          

                                </div><input type="button" name="next" class="next action-button nextInfoBtn" value="التالي" />
                                <p class="errorRquired1" style="color:red"></p>
                                </fieldset>
                            <fieldset data-set="2">
                                <div class="form-card" style="text-align: end;">
                                    <div class="memberSelect">
                                        <label for="member"> يرجى تحميل الصورة الشخصية </label>
                                        <input type="file" class="form-control" name="image" id="image" accept="image/png, image/gif, image/jpeg" required>
                                    </div>
                                    <div class="memberSelect">
                                        <label for="member"> يرجى تحميل فيديو القصيدة   </label>
                                        <input type="file" name="video" id="video" accept="video/mp4,video/x-m4v,video/*" required>
                                         <label for="member" style="color:#b79045">  بجودة عالية وبوضوح الحجم 50ميغا – المدة لاتزيد عن 60 ثانية  </labe>
                                      
                                        <input type="hidden" id="video_name">
                                      
                                    </div>
                                   <br>
                                    <div class="memberSelect">
                                        <label for="member"> حمل القصيدة  </label>
                                        <input type="file" class="form-control" name="poem" id="poem" accept="application/pdf,application/vnd.ms-excel" required>
                                          <label for="member" style="color:#b79045">  مكتوبة بوضوح   </labe>
                                    </div>
                 <br>
                                </div> <input type="button" name="previous" class="previous action-button-previous preVisaBtn" value="السابق" /> <input type="button"  name="next" class="next action-button nextVisaBtn passportBtn" value="التالي" />
                            <p class="errorRquired2" style="color:red"></p>
                            </fieldset>
                            <fieldset data-set="3">
                                <div class="form-card" style="text-align: end;">
                                    <h2 style="text-align: end;" class="fs-title">حدثنا عنك </h2>
                                    <textarea name="description" id="description" cols="30" rows="10" class="from-control">

                                    </textarea>
                                </div>
                                
                                <div class="form-group">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="FieldsetCheck" >
      <label class="form-check-label" for="FieldsetCheck">
        يرجى الاطلاع على الشروط والأحكام الخاصة في البرنامج قبل تأكيد التسجيل 
      </label>
    </div>
  </div>
                                
                                
                                
                                
                                
                                <input type="submit" name="make_payment" disabled="disabled" id="confirmBtn" class="next action-button confirmBtn nextpayBtn" value="تأكيد" />
                            <p class="errorRquired3" style="color:red"></p>
                            </fieldset>

                            <fieldset>
                                <div class="form-card">
                                    <div class="row justify-content-center" style="background: #fff;">
                                        <div class="col-3 col-sm-1 img-error">
                                             <div class="dots-bars-2"></div>
                                             <img width="90px" src="public/ok-img.png" class="fit-image">
                                             <img width="60px" src="https://www.freeiconspng.com/thumbs/error-icon/round-error-icon-16.jpg" class="fit-image error">
                                        </div>
                                    </div> <br>
                                    <h2 class="fs-title text-center msg-header"></h2> <br><br>
                                    <div style="margin-top:-1rem;background: #fff;" class="row justify-content-center">
                                        <div class="col-12 text-center msg-content">
                                            <h5></h5>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>
                        </form>
                    </div>
                </div>

                <!--<img src="public/web-03.png" alt="">-->
            </div>









        </div>
    </div>
</div>
    
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.14.0-beta3/js/bootstrap-select.min.js" integrity="sha512-yrOmjPdp8qH8hgLfWpSFhC/+R9Cj9USL8uJxYIveJZGAiedxyIxwNw4RsLDlcjNlIRR4kkHaDHSmNHAkxFTmgg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://unpkg.com/filepond-plugin-file-validate-size/dist/filepond-plugin-file-validate-size.js"></script>
    <script src="https://unpkg.com/filepond/dist/filepond.js"></script>
    <script>
        FilePond.registerPlugin(FilePondPluginFileValidateSize);
        const inputElement = document.querySelector('#video');
        
        const pond = FilePond.create(inputElement,{
            maxFileSize: '50MB'
        });
         FilePond.setOptions({
            server: {
                url: '/shaer/upload',
                process:{
                    headers: {
                    'X-CSRF_TOKEN': '<?php echo e(csrf_token()); ?>'
                    },
                    onload: (response) => { document.getElementById('video_name').value  = response; },
                    onerror: (response) => { alert('please try after one minute'); }
                }
            }
        });
    </script>
    <script>
        $(document).ready(function(){

var current_fs, next_fs, previous_fs; //fieldsets
var opacity;

$(".next").click(function(){





current_fs = $(this).parent();
next_fs = $(this).parent().next();

//Add Class Active
// $("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");

  function validateEmail(email) {
    var re = /^(([a-zA-Z0-9]+)|([a-zA-Z0-9]+((?:\_[a-zA-Z0-9]+)|(?:\.[a-zA-Z0-9]+))*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-zA-Z]{2,6}(?:\.[a-zA-Z]{2})?)$)/;
    return re.test(email);
  }

if(current_fs.data('set') == 1){
    var selectpickerCheck  = $('#selectpicker').val();
    if($('#name').val() == '' || $('#email').val() == '' ||  $('#mobile').val() == '' || $('#age').val() == ''|| $('#city').val() == '' || $('#nationality').val() == ''){
       $('.errorRquired1').text('جميع الحقول مطلوبة');
    }else{
        var email = $("#email").val();
        if (validateEmail(email)) {
                        $.ajaxSetup({
                          headers: {
                              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                          }
                        });
                        $.ajax({
                            'url': 'checkEmail/'+email,
                            'type': 'GET',
                            'dataType': 'json',
                             data: email,
                             cache:false,
                             contentType: false,
                             processData: false,
                            success: function (response) {
                                    $('.errorRquired1').text('');
                                    $('.invalidEmailMSG').css('visibility','hidden');
                                    //show the next fieldset
                                    next_fs.show();
                                    //hide the current fieldset with style
                                    current_fs.animate({opacity: 0}, {
                                    step: function(now) {
                                    // for making fielset appear animation
                                    opacity = 1 - now;
                            
                                    current_fs.css({
                                    'display': 'none',
                                    'position': 'relative'
                                    });
                                    next_fs.css({'opacity': opacity});
                                    },
                                    duration: 600
                                    });
                            },
                            error: function (xhr) {
                                   $("#progressbar li#account").removeClass("active");
                                   $('.errorRquired1').text('هذا البريد الالكتروني مستخدم من قبل شخص آخر');
                            }
                        });

        }else{
            $('.invalidEmailMSG').css('visibility','visible');
            $('.errorRquired1').text('يجب إدخال بريد إلكتروني صالح');
        }

    }
}
if(current_fs.data('set') == 2){
    var file1 = document.getElementById("image");
    var file2 = document.getElementById("video_name");
    var file3 = document.getElementById("poem");
    if(file1.files.length == 0  || file2.value.length == 0  || file3.files.length == 0 ){
      $('.errorRquired2').text('جميع الحقول مطلوبة');
    }else{
        $('.errorRquired2').text('');
        //show the next fieldset
        next_fs.show();
        //hide the current fieldset with style
        current_fs.animate({opacity: 0}, {
        step: function(now) {
        // for making fielset appear animation
        opacity = 1 - now;

        current_fs.css({
        'display': 'none',
        'position': 'relative'
        });
        next_fs.css({'opacity': opacity});
        },
        duration: 600
        });
    }
}

if(current_fs.data('set') == 3){
    if($('#badgeName').val() == '' || $('#badgeSide').val() == '' || $('#badgeJob').val() == ''){
       $('.errorRquired3').text('جميع الحقول مطلوبة');
    }else{
        $('.errorRquired3').text('');
        //show the next fieldset
        next_fs.show();
        //hide the current fieldset with style
        current_fs.animate({opacity: 0}, {
        step: function(now) {
        // for making fielset appear animation
        opacity = 1 - now;

        current_fs.css({
        'display': 'none',
        'position': 'relative'
        });
        next_fs.css({'opacity': opacity});
        },
        duration: 600
        });
    }
}


});

$(".previous").click(function(){

current_fs = $(this).parent();
previous_fs = $(this).parent().prev();

//Remove class active
// $("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");

//show the previous fieldset
previous_fs.show();

//hide the current fieldset with style
current_fs.animate({opacity: 0}, {
step: function(now) {
// for making fielset appear animation
opacity = 1 - now;

current_fs.css({
'display': 'none',
'position': 'relative'
});
previous_fs.css({'opacity': opacity});
},
duration: 600
});
});

$('.radio-group .radio').click(function(){
$(this).parent().find('.radio').removeClass('selected');
$(this).addClass('selected');
});

$(".submit").click(function(){
return false;
})

});


const checkbox = document.getElementById('FieldsetCheck');
const conBtn = document.getElementById('confirmBtn');

checkbox.addEventListener('change', (event) => {
  if (event.currentTarget.checked) {
    window.open("https://projects.datatime4it.com/poet/conditions", '_blank', 'location=yes,height=870,width=820,scrollbars=yes,status=yes');
    $("#confirmBtn").removeAttr("disabled");
  } else {
      $("#confirmBtn").removeAttr("disabled");
      conBtn.setAttribute("disabled", "disabled");
  }
})
    </script>
    <script>

         $('.nextInfoBtn').click(function(){
              if($('#name').val() == '' || $('#email').val() == '' ||  $('#mobile').val() == '' || $('#age').val() == ''|| $('#city').val() == '' || $('#nationality').val() == ''){

             }else{
                 $("#progressbar li#account").addClass("active");
             }

        });

         $('.nextVisaBtn').click(function(){
            var file11 = document.getElementById("image");
            var file22 = document.getElementById("video_name");
            var file33 = document.getElementById("poem");
            if(file11.files.length == 0  || file22.value.length == 0  || file33.files.length == 0 ){
            }else{
                    $("#progressbar li#payment").addClass("active");
                }
        });

         $('.preVisaBtn').click(function(){
            $("#progressbar li#account").removeClass("active");
        });

        $('.prepayBtn').click(function(){
            $("#progressbar li#payment").removeClass("active");
        });



        $('.nextpayBtn').click(function(){
            

        });

         $('.preConfirmBtn').click(function(){
            $("#progressbar li#services").removeClass("active");
        });


        $('.nextservicesBtn').click(function(){

                if($('#inBahreen').val() == 'No' && $('#member').val() == 'No' && file.files.length == 0 ){

                }else{
                    $("#progressbar li#confirm").addClass("active");
                }
        });

         $('.preservicesBtn').click(function(){
            $("#progressbar li#confirm").removeClass("active");
        });

    </script>
    <script>
    $(function () {
      
            $('#msform').submit(function (e) {
                    e.preventDefault();
                   
                    var full_number = phone_number.getNumber(intlTelInputUtils.numberFormat.E164);
                    $("input[name='mobile'").attr('type','text');
                    $("input[name='mobile'").val(full_number);
                    var name = $('#name').val();
                    var mobile = $('#mobile').val();
                    var email = $('#email').val();
                    
                    var birthdate_type = $('#birthdate_type').val();
                    var day = $('#day').val();
                    var month = $('#month').val();
                    var year = $('#year').val();
                    
                    var hobbies = $('#hobbies').val();
                    var nationality = $('#nationality').val();
                    var city = $('#city').val();
                    var gender = $('#gender').val();
                    var description = $('#description').val();
                    var facbook = $('#facebook_account').val();
                    var instagram = $('#instagram_account').val();
                    var twitter = $('#twitter_account').val();
                
                
                    var fd = new FormData();

                    var url = $(this).attr('action');
                    fd.append('name',name);
                    fd.append('mobile',mobile);
                    fd.append('email',email);
                    
                    fd.append('birthdate_type',birthdate_type);
                    fd.append('day',day);
                    fd.append('month',month);
                    fd.append('year',year);
                    
                    fd.append('nationality',nationality);
                    fd.append('city',city);  
                    fd.append('gender',gender);
                    fd.append('hobbies','');
                    fd.append('facbook',facbook);
                    fd.append('instagram',instagram);
                    fd.append('twitter',twitter);
                    fd.append('description',description);
                    fd.append('image', $('input#image')[0].files[0]);
                    fd.append('video', $('#video_name').val());
                    fd.append('poem', $('input#poem')[0].files[0]);
              
                        $.ajaxSetup({
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                            }
                        });
                        $.ajax({
                            'url': url,
                            'type': 'POST',
                            'dataType': 'json',
                                data: fd,
                                cache:false,
                                contentType: false,
                                processData: false,
                            success: function (response) {
                                        $('.dots-bars-2').css('display','none');
                                        $('h2.msg-header').text('تسجيلك تم بنجاح');
                                        $('.msg-content h5').text('الرجاء متابعة البريد الإلكتروني والبريد الغير هام لإستلام بادج الدخول');
                            }
                        });
                
                    
                });

            });
    </script>
       
  
<script>
    var phone_number = window.intlTelInput(document.querySelector("#mobile"), {
     separateDialCode: true,
     preferredCountries:["sa"],
     hiddenInput: "full",
     utilsScript: "//cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.3/js/utils.js"
});
$('#selectpicker').selectpicker();
$('.filter-option-inner-inner').text('قم باختيار واحدة أو أكثر');

 $('#mobile').keypress(function(e) {
    var mobile = $(this).val();
    if(mobile.length == 9){
        e.preventDefault();
    }
});
</script>
</body>
</html>
<?php /**PATH /home/festivalgcc/public_html/shaer/resources/views/registered/index.blade.php ENDPATH**/ ?>