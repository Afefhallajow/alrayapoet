
<!-- BEGIN: Vendor JS-->
<script src="<?php echo e(asset('public/assets/vuexy/vendors/js/vendors.min.js')); ?>"></script>
<!-- BEGIN Vendor JS-->


<script src="<?php echo e(asset('public/assets/vuexy/vendors/js/extensions/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/vuexy/vendors/js/extensions/moment.min.js')); ?>"></script>

<!-- BEGIN: Page Vendor JS-->
<script src="<?php echo e(asset('public/assets/vuexy/vendors/js/tables/datatable/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/vuexy/vendors/js/tables/datatable/datatables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/vuexy/vendors/js/tables/datatable/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/vuexy/vendors/js/tables/datatable/responsive.bootstrap4.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/vuexy/vendors/js/tables/datatable/datatables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/vuexy/vendors/js/tables/datatable/jszip.min.js')); ?>"></script>




<script src="<?php echo e(asset('public/assets/vuexy/vendors/js/tables/datatable/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/vuexy/vendors/js/tables/datatable/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/vuexy/vendors/js/tables/datatable/buttons.bootstrap4.min.js')); ?>"></script>

<script src="<?php echo e(asset('public/assets/vuexy/vendors/js/forms/validation/jquery.validate.min.js')); ?>"></script>
<!-- END: Page Vendor JS-->
<script src="<?php echo e(asset('public/assets/vuexy/js/scripts/bootbox/bootbox.min.js')); ?>"></script>

<!-- BEGIN: Theme JS-->
<script src="<?php echo e(asset('public/assets/vuexy/js/core/app-menu.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/vuexy/js/core/app.js')); ?>"></script>


<!-- END: Theme JS-->
<!-- BEGIN: Page JS-->
<!-- END: Page JS-->

<script>
    function detectMob() {
        const toMatch = [
            /Android/i,
            /webOS/i,
            /iPhone/i,
            /iPad/i,
            /iPod/i,
            /BlackBerry/i,
            /Windows Phone/i
        ];

        return toMatch.some((toMatchItem) => {
                return navigator.userAgent.match(toMatchItem);
    });
    }
    $(window).on('load', function() {

        if (feather) {
            feather.replace({
                width: 14,
                height: 14
            });
        }


    })

    $(document).ready(function () {

        <?php if(session()->has('success')): ?>
feather.replace({
            width: 14,
            height: 14
        });
        toastr['success'](
            "<?php echo e(session()->get('success')); ?>",
            {
                closeButton: false,
                tapToDismiss: true
            }
        );
        <?php endif; ?>
    })


</script>

<?php echo $__env->yieldPushContent('script'); ?><?php /**PATH /home/alrayapoet/public_html/vision/resources/views/layouts/js.blade.php ENDPATH**/ ?>