<?php $__env->startPush('css'); ?>
<style>
   h4{
      color: white;
   }
   h2{
      color: white;
   }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row ">
       <div class="col-sm-12 col-lg-3">
          <div class="card shadow-base bg-primary card-img-holder text-white">
             <div class="card-body">
                <h4 class=" mb-2 text-center">
                   عدد المتقدمين
                </h4>
                <h2 class="mb-0 text-center">
                     0
                </h2>
             </div>
          </div>
       </div>
       <div class="col-sm-12 col-lg-3">
          <div class="card shadow-base bg-warning card-img-holder text-white">
             <div class="card-body">
                <h4 class=" mb-2 text-center">
                   عدد المتقدمين
                </h4>
                <h2 class="mb-0 text-center">0</h2>
             </div>
          </div>
       </div>
       <div class="col-sm-12 col-lg-3">
          <div class="card shadow-base bg-info card-img-holder text-white">
             <div class="card-body">
                <h4 class="mb-2 text-center">
                   عدد المتقدمين 
                </h4>
                <h2 class="mb-0 text-center">
                    0
                </h2>
             </div>
          </div>
       </div>
       <div class="col-sm-12 col-lg-3">
          <div class="card shadow-base bg-success card-img-holder text-white">
             <div class="card-body">
                <h4 class=" mb-2 text-center">
                    عدد المتقدمين 
                </h4>
                <h2 class="mb-0 text-center">
                   0
                </h2>
             </div>
          </div>
       </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.appp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/festivalgcc/public_html/shaer/resources/views/home.blade.php ENDPATH**/ ?>