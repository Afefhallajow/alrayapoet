<?php $__env->startPush('css'); ?>
<style>
   h4{
      color: white;
   }
   h2{
      color: white;
   }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row ">
       <div class="col-sm-12 col-lg-6">
          <div class="card shadow-base bg-primary card-img-holder text-white">
             <div class="card-body">
                 <?php if(Auth::user()->type != 2): ?>
                    <h4 class=" mb-2 text-center">
                       عدد المتقدمين
                    </h4>
                    <h2 class="mb-0 text-center">
                         <?php echo e($all); ?>

                    </h2>
                <?php else: ?>
                    <h4 class=" mb-2 text-center">
                        متقدمين تم تقييمهم
                    </h4>
                    <h2 class="mb-0 text-center">
                         <?php echo e($doneEv); ?>

                    </h2>
                <?php endif; ?>
             </div>
          </div>
       </div>
       <!--<div class="col-sm-12 col-lg-3">-->
       <!--   <div class="card shadow-base bg-warning card-img-holder text-white">-->
       <!--      <div class="card-body">-->
       <!--         <h4 class=" mb-2 text-center">-->
       <!--            عدد المقبولين-->
       <!--         </h4>-->
       <!--         <h2 class="mb-0 text-center">-->
       <!--             <?php echo e($accept); ?>-->
       <!--         </h2>-->
       <!--      </div>-->
       <!--   </div>-->
       <!--</div>-->
       <!--<div class="col-sm-12 col-lg-3">-->
       <!--   <div class="card shadow-base bg-info card-img-holder text-white">-->
       <!--      <div class="card-body">-->
       <!--         <h4 class="mb-2 text-center">-->
       <!--            عدد المرفوضين -->
       <!--         </h4>-->
       <!--         <h2 class="mb-0 text-center">-->
       <!--             <?php echo e($refuse); ?>-->
       <!--         </h2>-->
       <!--      </div>-->
       <!--   </div>-->
       <!--</div>-->
       <div class="col-sm-12 col-lg-6">
          <div class="card shadow-base bg-success card-img-holder text-white">
             <div class="card-body">
                 <?php if(Auth::user()->type != 2): ?>
                    <h4 class=" mb-2 text-center">
                        عدد المستخدمين 
                    </h4>
                    <h2 class="mb-0 text-center">
                       <?php echo e($users); ?>

                    </h2>
                <?php else: ?>
                    <h4 class=" mb-2 text-center">
                        متقدمين بحاجة للتقييم  
                    </h4>
                    <h2 class="mb-0 text-center">
                       <?php echo e($needEv); ?>

                    </h2>
                <?php endif; ?>
             </div>
          </div>
       </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.appp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/visionpoet/public_html/vision/resources/views/home.blade.php ENDPATH**/ ?>