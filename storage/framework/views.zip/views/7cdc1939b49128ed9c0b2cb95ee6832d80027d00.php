<div class="main-menu menu-fixed menu-light menu-accordion menu-shadow" data-scroll-to-active="true">
    <div class="navbar-header">
        <ul class="nav navbar-nav flex-row">
            <li class="nav-item mr-auto"><a class="navbar-brand" href="<?php echo e(url('/home')); ?>">
                    
                    <span class="brand-logo">
                            </span>
                    <h2 class="brand-text"> لوحة التحكم</h2>
                </a></li>
            <li class="nav-item nav-toggle"><a class="nav-link modern-nav-toggle pr-0" data-toggle="collapse"><i class="d-block d-xl-none text-primary toggle-icon font-medium-4" data-feather="x"></i><i class="d-none d-xl-block collapse-toggle-icon font-medium-4  text-primary" data-feather="disc" data-ticon="disc"></i></a></li>
        </ul>
    </div>
    <div class="shadow-bottom"></div>
    <div class="main-menu">
        <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation" >
           <?php if(Auth::user()->type == 1 || Auth::user()->type == 3): ?>
                <li class="br-menu-item">
                    <a href="#" class="br-menu-link with-sub " >
                        <i data-feather="layers" class="text-primary"></i>
                        <span class="menu-item-label">شاعر الراية</span>
                    </a><!-- br-menu-link -->
                    <ul class="br-menu-sub">
                        <?php if(Auth::user()->type == 1 || Auth::user()->type == 3): ?>
                        <li class="sub-item"><a href="<?php echo e(url('/show/all')); ?>" class="sub-link"><i data-feather="circle" class="text-primary"></i> المتقدمين </a></li>
                        <?php endif; ?>
                        <?php if(Auth::user()->type == 1 || Auth::user()->type == 3): ?>
                        <li class="sub-item"><a href="<?php echo e(url('/show/accept')); ?>" class="sub-link1"><i data-feather="circle" class="text-primary"></i> المرشحين </a></li>
                        <li class="sub-item"><a href="<?php echo e(route('participants')); ?>" class="sub-link2"><i data-feather="circle" class="text-primary"></i> المشاركين </a></li>             
                        <?php endif; ?>
                    </ul>
                </li>
            <?php endif; ?>
           <?php if(Auth::user()->type == 1 || Auth::user()->type == 3): ?>
                <li class="br-menu-item">
                    <a href="#" class="br-menu-link with-sub " >
                        <i data-feather="layers" class="text-primary"></i>
                        <span class="menu-item-label">المتأهلين</span>
                    </a><!-- br-menu-link -->
                    <ul class="br-menu-sub">
                        <li class="sub-item"><a href="<?php echo e(url('qualified/khaild')); ?>" class="sub-link"><i data-feather="circle" class="text-primary"></i> خالد المريخي </a></li>
                        <li class="sub-item"><a href="<?php echo e(url('qualified/nasser')); ?>" class="sub-link1"><i data-feather="circle" class="text-primary"></i> ناصر السبيعي </a></li>
                        <li class="sub-item"><a href="<?php echo e(url('qualified/naif')); ?>" class="sub-link2"><i data-feather="circle" class="text-primary"></i> نايف صقر </a></li>             
                        <li class="sub-item"><a href="<?php echo e(route('ref-evaluations')); ?>" class="sub-link2"><i data-feather="circle" class="text-primary"></i> المشتركين بين جميع الحكام </a></li>             
                    </ul>
                </li>
            <?php endif; ?>
            
        <!-- br-menu-item -->
         <?php if(Auth::user()->type == 1): ?>
            <li class="br-menu-item">
                    <a href="<?php echo e(route('add_new_user')); ?>" class="br-menu-link" >
                        <i data-feather="user" class="text-primary"></i>
                        <span class="menu-item-label">المستخدمين</span>
                    </a>
            </li>
         <?php endif; ?>
         <?php if(Auth::user()->type == 2): ?>
          <li class="sub-item"><a href="<?php echo e(url('/evaluator-show/needEvulator')); ?>" class="sub-link2"><i data-feather="circle" class="text-primary"></i> متقدمين بحاجة تقييم </a></li>             
          <li class="sub-item"><a href="<?php echo e(url('/evaluator-show/done')); ?>" class="sub-link1"><i data-feather="circle" class="text-primary"></i> متقدمين تم تقييمهم </a></li>    
           
         <?php endif; ?>
        <?php if(Auth::user()->type == 4): ?>
            <li class="sub-item"><a href="<?php echo e(url('/referee-show/needEvulator')); ?>" class="sub-link2"><i data-feather="circle" class="text-primary"></i>  المرشحين </a></li>             
            <li class="sub-item"><a href="<?php echo e(url('/referee-show/done')); ?>" class="sub-link1"><i data-feather="circle" class="text-primary"></i> المتأهلين  </a></li>    
         <?php endif; ?>
         <?php if(Auth::user()->type == 1): ?>
            <li class="br-menu-item">
                    <a href="<?php echo e(route('evaluations')); ?>" class="br-menu-link" >
                        <i data-feather="link" class="text-primary"></i>
                        <span class="menu-item-label">تقييمات الفرز</span>
                    </a>
            </li>
            <!--<li class="br-menu-item">-->
            <!--        <a href="<?php echo e(route('ref-evaluations')); ?>" class="br-menu-link" >-->
            <!--            <i data-feather="link" class="text-primary"></i>-->
            <!--            <span class="menu-item-label">تقييمات الحكام</span>-->
            <!--        </a>-->
            <!--</li>-->
        <?php endif; ?>
        </ul>
    </div>
</div><?php /**PATH /home/alrayapoet/public_html/vision/resources/views/layouts/menu.blade.php ENDPATH**/ ?>