
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>  شاعر الراية</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Amiri&family=Cairo:wght@200&family=Montserrat:wght@100&family=Poppins:wght@400;500;600&family=Roboto+Serif:wght@100&display=swap" rel="stylesheet">
    <link href="//db.onlinewebfonts.com/c/593331e50d21b6415d53fc7c416b5b8e?family=FrutigerLTArabic-75Black" rel="stylesheet" type="text/css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/css/bootstrap-select.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.18/css/bootstrap-select.min.css" integrity="sha512-ARJR74swou2y0Q2V9k0GbzQ/5vJ2RBSoCWokg4zkfM29Fb3vZEQyv0iWBMW/yvKgyHSR/7D64pFMmU8nYmbRkg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.css" />
    <link href="//db.onlinewebfonts.com/c/8e84296a186f1941f28261b7dc98a78b?family=FrutigerLTArabic-45Light" rel="stylesheet" type="text/css"/>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Noto+Kufi+Arabic:wght@300&family=Tajawal:wght@200;300;400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="public/assets/register/css/style.css">
    <link href="https://unpkg.com/filepond/dist/filepond.css" rel="stylesheet" />
    <link href="public/assets/register/hijri/css/bootstrap-datetimepicker.css" rel="stylesheet" />
    <style>
@import  url('https://fonts.googleapis.com/css2?family=Noto+Kufi+Arabic:wght@300&family=Tajawal:wght@200;300;400;500&display=swap');
</style>
    <style>
    
        .requiredStar:after {
            content:" *";
            color: red;
            font-size: 1.2rem;
          }
    
        fieldset.filepond--file-wrapper{
            background: #b79045  !important;
        }
        [data-filepond-item-state='processing-complete'] .filepond--action-revert-item-processing svg,.filepond--file-action-button.filepond--file-action-button svg  {
            margin-top: -.5rem !important;
        }
        section.header {
    background: #b79045;
            
        }
        #progressbar li.active:before, #progressbar li.active:after {
    background: #b79045;
}


.justify-content-center {
    
    
    background-color: #b79045;
}

#msform .action-button {
    width: 100px;
    background: #b79045;}
    
    .labelclass {
    float: right;  
  }
  .form-group label:before{
      
      float: right;
  }
  body{
    background-color: #b79045;
    font-family: 'Tajawal', sans-serif;
  }
  
  input[type="file"]{
      direction: rtl;
  }
  
  #msform fieldset .form-card {
    box-shadow: none !important;
}
h5 {
    
    font-family: 'Tajawal';
}
.fs-title {
  
    font-family: 'Tajawal';
}

.loader {
  border: 16px solid #f3f3f3;
  border-radius: 50%;
  border-top: 16px solid #b79045;
  width: 120px;
  height: 120px;
  -webkit-animation: spin 2s linear infinite; /* Safari */
  animation: spin 2s linear infinite;
  margin-left: -30px;
}

/* Safari */
@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes  spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

#msform input{
   border: 1px solid #ccc; 
   padding: 4px 8px 4px 8px; 
    
}

.filepond--root .filepond--credits[style] {
    visibility: hidden;
}

.form-group label:before {

    border: 2px solid #b79045;
    
}

.form-group input:checked + label:after {
    content: '';
    display: block;
    position: absolute;
    top: 5px;
    right: -22px;
    width: 6px;
    height: 14px;
    border: solid #b79045;
    border-width: 0 2px 2px 0;
    transform: rotate(45deg);
}

label.float-right, label.labelFloatRight {
    font-size: 13px;
    font-family: 'Tajawal';
}
#msform{
    display:none;
}
    </style>
</head>
<body>


<section class="header" >
    <h1 style="font-family: 'Tajawal', sans-serif;">للمشاركة في البرنامج</h1>
</section>

    <!-- MultiStep Form -->
<div class="container-fluid" id="grad1">
    <div class="row justify-content-center mt-0">
        <div class="col-11 col-sm-9 col-md-7 col-lg-9 text-center p-0 mt-3 mb-2">
            <div class="card px-0 pb-0 mt-3 mb-3">
                <!--<img class="img-line" src="public/w-9.png" alt="">-->
                <div class="row">
                    <div class="col-md-12 mx-0">
                        <div class="conditions" style="height:auto;direction:rtl;text-align:right;padding:1rem">
                            <h4>
                        شروط المشاركة في مسابقة برنامج شاعر الراية
                              </h4>
                              <h4>
                                  
                              </h4>
                              <h4>
                                  الشروط الخاصة بآلية ومحتوى المشاركة في مسابقة برنامج شاعر الراية:
                              </h4>
                            <ul style="padding:1rem">
                                <li>
                                    التسجيل فقط عبر (البوابة) الرسمية للبرنامج
                                </li>
                                <li>
                                   عمر المتقدم لا يقل عن 18
                                </li>
                                <li>
                                    المشاركة(القصيدة) بقصيدة نبطية موزونة ومقفاه تتحدث عن رؤية المملكة 2030
                                </li>
                                <li>
                                     المشاركة(القصيدة) لم يسبق لها الظهور الإعلامي في أي وسيلة إعلامية او أي مسابقة أخرى
                                </li>
                                <li>
                                    ابيات المشاركة (القصيدة) لا تقل عن 12 بيت ولا تزيد عن 15 بيت
                                </li>
                                <li>
                                   يتم رفع المشاركة (القصيدة) عبر (البوابة) بالصيغ التالية:
                                </li>
                                <li style="list-style-type: none;">
                                    <ul style="list-style-type: ' - ';">
                                            <li>
                                                نص مكتوب (خالي من الأخطاء المطبعية)
                                            </li>
                                            <li>
                                                فيديو (عالي الجودة) يظهر فيه صاحب المشاركة (القصيدة) وهو يقوم بإلقائها بشكل واضح و مميز لمدة لا تتجاوز (120 ثانية)
                                            </li>
                                    </ul>
                                </li>
                            </ul>
                            <!--<h4>-->
                            <!--    الشروط والأحكام-->
                            <!--</h4>-->
                            <!--<ul style="padding:1rem;list-style:none">-->
                            <!--    <li>-->
                            <!--        1-1 نرحب بكم في بوابة التسجيل لمسابقة شاعر الرؤية -->

                            <!--    </li>-->
                            <!--    <li style="visibility:hidden">-</li>-->
                            <!--    <li>-->
                            <!--        1-2 تحكم شروط الاستخدام العلاقة بيننا وبين كل مستخدم للبوابة الالكتروني (أنت)، لذا يرجى قراءة هذه الشروط بتمعن -->
                            <!--    </li>-->
                            <!--    <li style="visibility:hidden">-</li>-->
                            <!--    <li>-->
                            <!--        قبل المباشرة بتسجيل مشاركتك في المسابقة، إن أرسال مشاركتك يشير إلى قبولك لهذه الشروط وبأنك موافق على الالتزام بها. -->
                            <!--    </li>-->
                            <!--    <li style="visibility:hidden">-</li>-->
                            <!--    <li>-->
                            <!--        1-3 تُطبق هذه الشروط بصرف النظر عن نوع الجهاز الذي تستخدمه للدخول الي البوابة (بما في ذلك الكمبيوتر أو الكمبيوتر المحمول أو الهاتف الجوال أو الجهاز اللوحي وغيرها من الأجهزة)، وتطبق هذه الشروط أيضاً في حال الدخول إلى البوابة عبر مواقع الغير، شريطة أن تكون على علم بأن الشروط الخاصة بخدمات الغير (وسياسات الخصوصية الخاصة بهم) قد تطبق أيضاً.-->
                            <!--    </li>-->
                            <!--</ul>-->
                            <!--<h4>-->
                            <!--    2- المحتوى-->
                            <!--</h4>-->
                            <!--<ul style="padding:1rem;list-style:none">-->
                            <!--   <li>-->
                            <!--       2-1 تكون كافة الحقوق بما فيها، دون حصر، حقوق التأليف النشر وحقوق قواعد البيانات والعلامات التجارية في الخدمات ومحتوياتها، سواء كانت صوتيةً أم نصيةً، أو صوراً، أو فيديوهات، أو بأي شكل آخر ("المحتوى") ملكيةً للبرنامج ومرخصةً لنا. كما يكون هذا المحتوى محمياً.-->
                            <!--   </li> -->
                            <!--    <li style="visibility:hidden">-</li>-->
                            <!--    <li>-->
                            <!--        2-2 إنك توافق على دخولك إلى بوابة التسجيل في المسابقة للاستعمال الشخصي فقط وليس للاستخدام العام أو التجاري، ولا يصرح لك نسخ أو نشر أو التخزين في أية وسيلة، أو بث أو نقل أو إعادة نقل أو تعديل أو العرض العام لأية أجزاء من المحتوى دون الحصول على الموافقة الخطية بذلك.-->
                            <!--    </li>-->
                            <!--    <li style="visibility:hidden">-</li>-->
                            <!--    <li>-->
                            <!--        2-3 يصرح لك استخدام البوابة للأغراض الشخصية وغير التجارية، ولا يصرح لك تعديل المحتوى أو إزالة أية حقوق طبع ونشر.-->
                            <!--    </li>-->
                            <!--    <li style="visibility:hidden">-</li>-->
                            <!--    <li>-->
                            <!--        2-4 إن جميع العلامات الفارقة واللوغو والعلامات المسجلة التابعة لبرنامج شاعر الرؤية هي علامة تجارية مسجلةً لبرنامج شاعر الرؤية.-->
                            <!--    </li>-->
                            <!--</ul>-->
                            <!--<h4>-->
                            <!--    3- المشاركات-->
                            <!--</h4>-->
                            <!--<p>الرجاء قراءة هذا الجزء بتمعن قبل تقديم مشاركتك.</p>-->
                            <!--<ul style="padding:1rem;list-style:none">-->
                            <!--    <li>-->
                            <!--        3-1 عند تسجيلك المشاركة في المسابقة (بما في ذلك أية نصوص، أو صور، أو فيديوهات، أو تسجيلات صوتية) -->
                            <!--    </li>-->
                            <!--    <li>-->
                            <!--        تمنحنا الحق الدائم والحصري كما ترخص لنا استخدام ونسخ وتعديل ونشر وترجمة واشتقاق أعمال من وتوزيع وتشغيل وعرض والتواصل مع العامة وممارسة كافة حقوق النشر والتأليف وحقوق الإعلان فيما يتعلق بذلك العمل و/ أو دمجه مع أعمال أخرى في أية وسيلة إعلامية معروفة حالياً أو قد تطور لاحقاً وطوال المدة الكاملة لأي من تلك الحقوق الممنوحة لذلك المحتوى، وفي حال عدم موافقتك على منح تلك الحقوق إلينا، عليك الامتناع عن تقديم المشاركة في المسابقة.-->
                            <!--    </li>-->
                            <!--    <li style="visibility:hidden">-</li>-->
                            <!--    <li>3-2 أنت المسؤول الوحيد عن المشاركة التي تقدمها على البوابة، وإن تقديم المشاركة يعني بأنك:</li>-->
                            <!--    <li style="visibility:hidden">-</li>-->
                            <!--    <li> (1) تتعهد بأن تلك المشاركة هي عملك الخاص وبأنك تمتلك الحق في تقديمها إلينا لاستخدامها في كافة الأغراض المذكورة أعلاه. </li>-->
                            <!--    <li style="visibility:hidden">-</li>-->
                            <!--    <li> -->
                            <!--    (2) توافق على التنازل عن أية حقوق معنوية في مشاركتك لأغراض تقديمها ونشرها على الخدمات ولاستخدامها لكافة الأغراض المذكورة.-->
                            <!--    </li>-->
                            <!--    <li style="visibility:hidden">-</li>-->
                            <!--    <li> -->
                            <!--    (3) تتعهد بأن مشاركتك هو أمر قانوني وأنها لا تخرق أية حقوق للغير ولا تتسبب بإيذاء أو إزعاج الآخرين و لا تحتوي على أية مواد مهينة أو مسيئة أو استخدام لغة غير مقبولة، أو جارحة أو مهددة أو عنيفة أو متعصبة (لدين أو عرق أو جنس أو ميول جنسية أو أصل أو عمر أو إعاقة أو حالة جسدية أو عقلية).-->
                            <!--    </li>-->
                            <!--    <li style="visibility:hidden">-</li>-->
                            <!--    <li>-->
                            <!--        (4) قد يشمل ذلك ممارسات غير قانونية (بما في ذلك دون حصر، الفيروسات أو أعمال القرصنة أو انتهاكات حقوق التأليف والنشر).-->
                            <!--    </li>-->
                            <!--    <li style="visibility:hidden">-</li>-->
                            <!--    <li>-->
                            <!--        (5) يشمل على وضع عناوين مواقع الكترونية أخرى تحتوي على مواد تنتهك حقوق الملكية الفكرية الخاصة بالغير ويشكل خرقاً لأي واجب قانوني خاص بالغير كالواجبات التعاقدية أو واجب السرية.-->
                            <!--    </li>-->
                            <!--    <li style="visibility:hidden">-</li>-->
                            <!--    <li>-->
                            <!--        (6) يشمل على انتحال شخصيات موظفينا أو المشاهير أو أية شخصيات أو أشخاص آخرين.-->
                            <!--    </li>-->
                            <!--    <li style="visibility:hidden">-</li>-->
                            <!--    <li>-->
                            <!--        (8) يشمل على أية محتويات تتسبب بالضرر لنا من أفعال تشوش أو تعطل فعالية أو ثبات أمن البوابة (بما في ذلك دون حصر الفيروسات والأعطال المفاجئة والفيروسات المتنقلة وفيروسات تروجان هورسيز أو أي شكل آخر من أشكال الفيروسات).-->
                            <!--    </li>-->
                            <!--    <li style="visibility:hidden">-</li>-->
                            <!--    <li>-->
                            <!--        4-2 نقوم بمحض اختيارنا بتحديد وجود أي خرق لأحد البنود أعلاه عند استخدامك لبوابة التسجيل. وعند حدوث أي خرق لأيّ من هذه البنود، فإننا نقوم باتخاذ الإجراءات التي نراها مناسبةً، بما فيها:-->
                            <!--    </li>-->
                            <!--    <li style="visibility:hidden">-</li>-->
                            <!--    <li>-->
                            <!--        أستباعد مشاركتك فور تأكيد أي من هذه التجاوزات -->
                            <!--    </li>-->
                            <!--    <li style="visibility:hidden">-</li>-->
                            <!--    <li>-->
                            <!--        (2) اتخاذ الاجراءات القانونية بحقك لتعويضنا عن كافة التكاليف على أساس التعويض بسبب الخرق-->
                            <!--    </li>-->
                            <!--    <li style="visibility:hidden">-</li>-->
                            <!--    <li>-->
                            <!--        (3) اتخاذ المزيد من الإجراءات القانونية بحقك.-->
                            <!--    </li>-->
                            <!--    <li style="visibility:hidden">-</li>-->
                            <!--    <li>-->
                            <!--        (4) الافصاح عن تلك المعلومات الضرورية إلى سلطات تنفيذ القوانين وفق ما نراه ضروري.-->
                            <!--    </li>-->
                            <!--</ul>-->
                            <!--<h4>-->
                            <!--    4- تسجيل المعلومات الخاصة بك -->
                            <!--</h4>-->
                            <!--<ul style="padding:1rem;list-style:none">-->
                            <!--    <li>-->
                            <!--        4-1يجب أن تكون جميع المعلومات التي تدلي بها عند تسجيل مشاركتك، أن تكون صحيحة ودقيقة ومستحدثة، وعليك ابلاغنا عن اي تحديث لمعلوماتك لغايات اتصالنا بك إن دعت الحاجة.-->
                            <!--    </li>-->
                            <!--    <li style="visibility:hidden">-</li>-->
                            <!--    <li>-->
                            <!--        4-1نحتفظ بحقنا بمنعك استخدام البوابة او جزء منها في أي وقت ودون انذار مسبق او أي مسؤولية علينا، بحال أنك خالفت هذه الشروط والاحكام أو اي قانون أو انظمة أو قمت باي أعمال غير اخلاقية أو أي سبب.-->
                            <!--    </li>-->
                            <!--    <li style="visibility:hidden">-</li>-->
                            <!--    <li>-->
                            <!--        4-3تخضع هذه الشروط وأي نزاع أو مطالبة تنشأ عن أو تتعلق بها أو بموضوعها أو صياغتها (بما في ذلك النزاعات أو المطالبات غير التعاقدية) وفقاً لقوانين المملكة العربية السعودية.-->
                            <!--    </li>-->
                            <!--    <li style="visibility:hidden">-</li>-->
                            <!--</ul>-->
                            
                            <div class="form-group" style="margin-right:2.5rem">
                                    <div class="form-check">
                                      <input class="form-check-input" type="checkbox" id="FieldsetCheck" >
                                      <label style="font-family: 'Tajawal', sans-serif;" class="form-check-label" id="myLabelcheck" for="FieldsetCheck">
                                            <a target="_blank" href="https://alrayapoet.com/conditions/" style="color:#b79045">
                                                 أوافق على الشروط والاحكام الخاصة بوابة تسجيل المشاركات لمسابقة (برنامج شاعر الراية )
                                            </a>
                                      </label>
                                    </div>
                                    
                            </div>
                            <div style="text-align:center">
                                <input style="border: 0 none;border-radius: 12px;ont-weight: bold;color: white;width: 100px;background: #b79045;cursor: pointer;padding: 10px 5px;margin: 10px 5px;" type="button"  name="next" class="next action-button lastAccept" id="lastAccept" value="التالي" />
                                <p class="pacceptmsg" style="color:red;visibility:hidden">
                                    يجب الموافقة على الشروط والأحكام</p>                            
                            </div>
                        </div>
                        <form id="msform" action="<?php echo e(url()->current()); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <ul id="progressbar">
                                <li style="font-family: 'Tajawal', sans-serif;" id="payment"><strong></strong>حدثنا عنك </li>
                                <li style="font-family: 'Tajawal', sans-serif;" id="account"><strong></strong>تحميل مشاركتك </li>
                                <li style="font-family: 'Tajawal', sans-serif;" class="active" id="personal">معلوماتك الشخصية </li>

                            </ul> <!-- fieldsets -->
                            <fieldset data-set="1">
                                <div class="form-card">
                                    <!--<h2 style="text-align:end" class="fs-title"> معلوماتك الشخصية</h2>-->
                                    <br>
                                    <div class="row box">
                                        <div class="col-md-6 div1">
                                            <label for="member" class="requiredStar float-right"> البريد الالكتروني </label>
                                            <input dir="rtl" type="email" required id="email" name="email" placeholder="" />
                                            <span class="invalidEmailMSG" style="position:absolute;color:red">*</span>
                                        </div>
                                        <div class="col-md-6 div2">
                                            <label for="member" class="requiredStar float-right">الاسم الكامل </label>
                                            <input dir="rtl" type="text" id="name" name="name" placeholder="" />
                                        </div>
                                    </div>
                                    <div class="row">

                                    <div class="col-md-6  mobile-clas">
                                         <label for="mobile" class="requiredStar float-right">رقم الجوال</label>
                                 <br>

                                            <input dir="rtl" type="number" pattern="\d*" maxlength="9" id="mobile" name="mobile" placeholder="" />
                                        </div>

                                        
                                        <div class="col-md-6">
                                            <label for="gender" class="requiredStar float-right">الجنس</label>
                                    <select style="font-family: 'Tajawal', sans-serif;" name="gender" id="gender" dir="rtl" class="form-control">
                                            <option value="ذكر">
                                                 ذكر </option>
                                            <option value="أنثى ">
                                                أنثى 
                                            </option>
                                    </select>
                                        </div>
                                    </div><br>
                                    <div class="row">
                                        <div class="col-lg-6">
                                                <label for="birthdate_type" class="requiredStar float-right">تاريخ الميلاد </label>
                                                <input type="text" dir="rtl" class="form-control hijri-date-input" name="birthdate_type" id="birthdate_type" />
                                       </div>
                                        <div class="col-lg-6">
                                        
                                    
                                      <label for="city" class="requiredStar float-right">الدولة المقيم فيها  </label>
                                   <select style="font-family: 'Tajawal', sans-serif;" type="text" id="city" name="city" dir="rtl"  class="form-control" required>
                                        <option value="" disabled>إختر</option>
  <option value="أفغانستان">أفغانستان</option>
  <option value="ألبانيا">ألبانيا</option>
  <option value="الجزائر">الجزائر</option>
  <option value="أندورا">أندورا</option>
  <option value="أنغولا">أنغولا</option>
  <option value="أنتيغوا وباربودا">أنتيغوا وباربودا</option>
  <option value="الأرجنتين">الأرجنتين</option>
  <option value="أرمينيا">أرمينيا</option>
  <option value="أستراليا">أستراليا</option>
  <option value="النمسا">النمسا</option>
  <option value="أذربيجان">أذربيجان</option>
  <option value="البهاما">البهاما</option>
  <option value="البحرين">البحرين</option>
  <option value="بنغلاديش">بنغلاديش</option>
  <option value="باربادوس">باربادوس</option>
  <option value="بيلاروسيا">بيلاروسيا</option>
  <option value="بلجيكا">بلجيكا</option>
  <option value="بليز">بليز</option>
  <option value="بنين">بنين</option>
  <option value="بوتان">بوتان</option>
  <option value="بوليفيا">بوليفيا</option>
  <option value="البوسنة والهرسك ">البوسنة والهرسك </option>
  <option value="بوتسوانا">بوتسوانا</option>
  <option value="البرازيل">البرازيل</option>
  <option value="بروناي">بروناي</option>
  <option value="بلغاريا">بلغاريا</option>
  <option value="بوركينا فاسو ">بوركينا فاسو </option>
  <option value="بوروندي">بوروندي</option>
  <option value="كمبوديا">كمبوديا</option>
  <option value="الكاميرون">الكاميرون</option>
  <option value="كندا">كندا</option>
  <option value="الرأس الأخضر">الرأس الأخضر</option>
  <option value="جمهورية أفريقيا الوسطى ">جمهورية أفريقيا الوسطى </option>
  <option value="تشاد">تشاد</option>
  <option value="تشيلي">تشيلي</option>
  <option value="الصين">الصين</option>
  <option value="كولومبيا">كولومبيا</option>
  <option value="جزر القمر">جزر القمر</option>
  <option value="كوستاريكا">كوستاريكا</option>
  <option value="ساحل العاج">ساحل العاج</option>
  <option value="كرواتيا">كرواتيا</option>
  <option value="كوبا">كوبا</option>
  <option value="قبرص">قبرص</option>
  <option value="التشيك">التشيك</option>
  <option value="جمهورية الكونغو الديمقراطية">جمهورية الكونغو الديمقراطية</option>
  <option value="الدنمارك">الدنمارك</option>
  <option value="جيبوتي">جيبوتي</option>
  <option value="دومينيكا">دومينيكا</option>
  <option value="جمهورية الدومينيكان">جمهورية الدومينيكان</option>
  <option value="تيمور الشرقية ">تيمور الشرقية </option>
  <option value="الإكوادور">الإكوادور</option>
  <option value="مصر">مصر</option>
  <option value="السلفادور">السلفادور</option>
  <option value="غينيا الاستوائية">غينيا الاستوائية</option>
  <option value="إريتريا">إريتريا</option>
  <option value="إستونيا">إستونيا</option>
  <option value="إثيوبيا">إثيوبيا</option>
  <option value="فيجي">فيجي</option>
  <option value="فنلندا">فنلندا</option>
  <option value="فرنسا">فرنسا</option>
  <option value="الغابون">الغابون</option>
  <option value="غامبيا">غامبيا</option>
  <option value="جورجيا">جورجيا</option>
  <option value="ألمانيا">ألمانيا</option>
  <option value="غانا">غانا</option>
  <option value="اليونان">اليونان</option>
  <option value="جرينادا">جرينادا</option>
  <option value="غواتيمالا">غواتيمالا</option>
  <option value="غينيا">غينيا</option>
  <option value="غينيا بيساو">غينيا بيساو</option>
  <option value="غويانا">غويانا</option>
  <option value="هايتي">هايتي</option>
  <option value="هندوراس">هندوراس</option>
  <option value="المجر">المجر</option>
  <option value="آيسلندا">آيسلندا</option>
  <option value="الهند">الهند</option>
  <option value="إندونيسيا">إندونيسيا</option>
  <option value="إيران">إيران</option>
  <option value="العراق">العراق</option>
  <option value="جمهورية أيرلندا ">جمهورية أيرلندا </option>
  <option value="فلسطين">فلسطين</option>
  <option value="إيطاليا">إيطاليا</option>
  <option value="جامايكا">جامايكا</option>
  <option value="اليابان">اليابان</option>
  <option value="الأردن">الأردن</option>
  <option value="كازاخستان">كازاخستان</option>
  <option value="كينيا">كينيا</option>
  <option value="كيريباتي">كيريباتي</option>
  <option value="الكويت">الكويت</option>
  <option value="قرغيزستان">قرغيزستان</option>
  <option value="لاوس">لاوس</option>
  <option value="لاوس">لاوس</option>
  <option value="لاتفيا">لاتفيا</option>
  <option value="لبنان">لبنان</option>
  <option value="ليسوتو">ليسوتو</option>
  <option value="ليبيريا">ليبيريا</option>
  <option value="ليبيا">ليبيا</option>
  <option value="ليختنشتاين">ليختنشتاين</option>
  <option value="ليتوانيا">ليتوانيا</option>
  <option value="لوكسمبورغ">لوكسمبورغ</option>
  <option value="مدغشقر">مدغشقر</option>
  <option value="مالاوي">مالاوي</option>
  <option value="ماليزيا">ماليزيا</option>
  <option value="جزر المالديف">جزر المالديف</option>
  <option value="مالي">مالي</option>
  <option value="مالطا">مالطا</option>
  <option value="جزر مارشال">جزر مارشال</option>
  <option value="موريتانيا">موريتانيا</option>
  <option value="موريشيوس">موريشيوس</option>
  <option value="المكسيك">المكسيك</option>
  <option value="مايكرونيزيا">مايكرونيزيا</option>
  <option value="مولدوفا">مولدوفا</option>
  <option value="موناكو">موناكو</option>
  <option value="منغوليا">منغوليا</option>
  <option value="الجبل الأسود">الجبل الأسود</option>
  <option value="المغرب">المغرب</option>
  <option value="موزمبيق">موزمبيق</option>
  <option value="بورما">بورما</option>
  <option value="ناميبيا">ناميبيا</option>
  <option value="ناورو">ناورو</option>
  <option value="نيبال">نيبال</option>
  <option value="هولندا">هولندا</option>
  <option value="نيوزيلندا">نيوزيلندا</option>
  <option value="نيكاراجوا">نيكاراجوا</option>
  <option value="النيجر">النيجر</option>
  <option value="نيجيريا">نيجيريا</option>
  <option value="كوريا الشمالية ">كوريا الشمالية </option>
  <option value="النرويج">النرويج</option>
  <option value="سلطنة عمان">سلطنة عمان</option>
  <option value="باكستان">باكستان</option>
  <option value="بالاو">بالاو</option>
  <option value="بنما">بنما</option>
  <option value="بابوا غينيا الجديدة">بابوا غينيا الجديدة</option>
  <option value="باراغواي">باراغواي</option>
  <option value="بيرو">بيرو</option>
  <option value="الفلبين">الفلبين</option>
  <option value="بولندا">بولندا</option>
  <option value="البرتغال">البرتغال</option>
  <option value="قطر">قطر</option>
  <option value="جمهورية الكونغو">جمهورية الكونغو</option>
  <option value="جمهورية مقدونيا">جمهورية مقدونيا</option>
  <option value="رومانيا">رومانيا</option>
  <option value="روسيا">روسيا</option>
  <option value="رواندا">رواندا</option>
  <option value="سانت كيتس ونيفيس">سانت كيتس ونيفيس</option>
  <option value="سانت لوسيا">سانت لوسيا</option>
  <option value="سانت فنسينت والجرينادينز">سانت فنسينت والجرينادينز</option>
  <option value="ساموا">ساموا</option>
  <option value="سان مارينو">سان مارينو</option>
  <option value="ساو تومي وبرينسيب">ساو تومي وبرينسيب</option>
  
  <option selected value="المملكة العربية السعودية">
      المملكة العربية السعودية
  </option>
  
  <option value="السنغال">السنغال</option>
  <option value="صربيا">صربيا</option>
  <option value="سيشيل">سيشيل</option>
  <option value="سيراليون">سيراليون</option>
  <option value="سنغافورة">سنغافورة</option>
  <option value="سلوفاكيا">سلوفاكيا</option>
  <option value="سلوفينيا">سلوفينيا</option>
  <option value="جزر سليمان">جزر سليمان</option>
  <option value="الصومال">الصومال</option>
  <option value="جنوب أفريقيا">جنوب أفريقيا</option>
  <option value="كوريا الجنوبية">كوريا الجنوبية</option>
  <option value="جنوب السودان">جنوب السودان</option>
  <option value="إسبانيا">إسبانيا</option>
  <option value="سريلانكا">سريلانكا</option>
  <option value="السودان">السودان</option>
  <option value="سورينام">سورينام</option>
  <option value="سوازيلاند">سوازيلاند</option>
  <option value="السويد">السويد</option>
  <option value="سويسرا">سويسرا</option>
  <option value="سوريا">سوريا</option>
  <option value="طاجيكستان">طاجيكستان</option>
  <option value="تنزانيا">تنزانيا</option>
  <option value="تايلاند">تايلاند</option>
  <option value="توغو">توغو</option>
  <option value="تونجا">تونجا</option>
  <option value="ترينيداد وتوباغو">ترينيداد وتوباغو</option>
  <option value="تونس">تونس</option>
  <option value="تركيا">تركيا</option>
  <option value="تركمانستان">تركمانستان</option>
  <option value="توفالو">توفالو</option>
  <option value="أوغندا">أوغندا</option>
  <option value="أوكرانيا">أوكرانيا</option>
  <option value="الإمارات العربية المتحدة">الإمارات العربية المتحدة</option>
  <option value="المملكة المتحدة">المملكة المتحدة</option>
  <option value="الولايات المتحدة">الولايات المتحدة</option>
  <option value="أوروغواي">أوروغواي</option>
  <option value="أوزبكستان">أوزبكستان</option>
  <option value="فانواتو">فانواتو</option>
  <option value="فنزويلا">فنزويلا</option>
  <option value="فيتنام">فيتنام</option>
  <option value="اليمن">اليمن</option>
  <option value="زامبيا">زامبيا</option>
  <option value="زيمبابوي">زيمبابوي</option>
                                    </select><br>
                                    
                                    
                                    
                                    </div>
                                        
                                        <div class="col-md-12">
                                            <label for="member" class="requiredStar float-right">الجنسية</label><br>
                                            <select id="nationality" name="nationality" dir="rtl" class="form-control">
                                               <option  value = "" disabled> - حدد خيارًا - </ option >
  <option  value = "جزائري" >
       جزائري 
  </option >
  <option  value = "بحريني" > 
  بحريني
  </option >


  <option  value = " egyptian " >
       مصرية </ option >
  <option  value = "إماراتي" >
       إماراتي </option >

  <option  value = "عراقي" >
       عراقي </option >
  <option  value = "أردني" >
       أردني </option >

  <option  value = "كويتي" >
       كويتي </option >

  <option  value = "لبناني" >
       لبناني </option >
  <option  value = "ليبي" >
       ليبي
   </option >
  <option  value = "مغربي" >
       مغربي 
   </option >

  <option  value = "قطري" >
       قطري </option >

  <option selected  value = "سعودي" >
       سعودي </option >
 
  <option  value = "سوداني" >
       سوداني </option >

  <option  value = "سوري" >
       سوري </option >
 
  <option  value = "تونسي" >
       تونسي </option >
    <option value="عماني">
        عماني
    </option>                                            
    <option value="فلسطيني">
        فلسطيني
    </option>                                            
                                            </select><br>
                                        </div>
                                    </div>

                                        <!--<div  dir="rtl" class="row">-->
                                           <!-- <div class="col-lg-6">-->
                                                
                                           <!--     <label dir="rtl"  for="birthdate_type" class="float-right">تاريخ الميلاد </label>-->
                                           <!--     <input type="text" class="form-control hijri-date-input" name="birthdate_type" id="birthdate_type" />-->
                                                <!--<select style="" name="birthdate_type" id="birthdate_type" dir="rtl" class="form-control">-->
                                                <!--    <option value="هجري">-->
                                                <!--         هجري </option>-->
                                                <!--    <option value="ميلادي">-->
                                                <!--        ميلادي -->
                                                <!--    </option>-->
                                                <!--</select>-->
                                           <!-- <br>-->
                                           <!--</div>-->
                                            
                                        <!--<div class=" col-md-3">-->
                                            
                                        <!--   <label class="labelclass float-right" for="inputState">السنة</label>-->
                                        <!--  <input dir="rtl" type="text" id="year" name="year" placeholder=" " />-->
                                        <!--</div>-->
                                        <!--<div class=" col-md-3">-->
                                            
                                        <!--  <label class="labelclass float-right" for="inputState">الشهر</label>-->
                                        <!--   <input dir="rtl" type="number" id="month" name="month" placeholder=" " />-->
                                        <!--</div>-->
                                        <!--<div class=" col-md-3">-->
                                            
                                        <!--  <label class="labelclass float-right"  for="inputZip">اليوم</label>-->
                                        <!--   <input dir="rtl" type="number" id="day" name="day" placeholder=" " />-->
                                        <!--</div>-->
  <!--</div>-->
                                   
                                  
                                    
                                <div class="row">
                                    <div class="col-lg-12">
                                        <label for="hobbies" class="float-right">حسابات التواصل الاجتماعي</label>
                                        <br>
                                         <div class="form-card" style="text-align: end;width:100%">
                                        <div class="memberSelect" style="text-align: end;">
                                        <label class="float-right" for="member">فيسبوك </label>
                                            <input dir="rtl" type="text" class="form-control" name="facebook" id="facebook_account">
                                        </div>
                                        <div class="memberSelect" style="text-align: end;">
                                        <label class="float-right" for="member">انستغرام </label>
                                            <input dir="rtl" type="text" class="form-control" name="instagram" id="instagram_account">
                                        </div>
                                        <div class="memberSelect" style="text-align: end;">
                                        <label class="float-right" for="member">تويتر </label>
                                            <input dir="rtl" type="text" class="form-control" name="twitter" id="twitter_account">
                                        </div>
                                        </div>
                                    </div>
                                </div>    
                                    
                          

                                </div><input style="font-family: 'Tajawal', sans-serif;border-radius: 12px;" type="button" name="next" class="next action-button nextInfoBtn" value="التالي" />
                                <p class="errorRquired1" style="color:red"></p>
                                </fieldset>
                            <fieldset data-set="2">
                                <div class="form-card" style="text-align: end;">
                                    <div class="memberSelect">
                                        <label class="requiredStar" style="font-family: 'Tajawal', sans-serif;"  for="member"> يرجى تحميل الصورة الشخصية </label>
                                        <input type="file" class="form-control" name="image" id="image" accept="image/png, image/gif, image/jpeg" required>
                                    </div>
                                    <div class="memberSelect">
                                        <label class="requiredStar" style="font-family: 'Tajawal', sans-serif;"  for="member"> يرجى تحميل فيديو القصيدة   </label>
                                        <input type="file" name="video" id="video" accept="video/mp4,video/x-m4v,video/*" required>
                                         <label for="member" style="font-family: 'Tajawal', sans-serif;color:#b79045">  بجودة عالية وبوضوح الحجم 500ميغا – المدة لاتزيد عن 120 ثانية  </labe>
                                      
                                        <input type="hidden" id="video_name">
                                      
                                    </div>
                                   <br>
                                    <div class="memberSelect">
                                        <label class="requiredStar"  style="font-family: 'Tajawal', sans-serif;" for="member"> حمل القصيدة  </label>
                                        <input style="margin-bottom:12px" type="file" class="form-control" name="poem" id="poem" required>
                                          <label for="member" style="font-family: 'Tajawal', sans-serif;color:#b79045">  مكتوبة بوضوح   </labe>
                                    </div>
                 <br>
                                </div> <input style="border-radius: 12px;" type="button" name="previous" class="previous action-button-previous preVisaBtn" value="السابق"  > <input style="border-radius: 12px;" type="button"  name="next" class="next action-button nextVisaBtn passportBtn" value="التالي" />
                            <p class="errorRquired2" style="color:red"></p>
                            </fieldset>
                            <fieldset data-set="3">
                                <div class="form-card" style="text-align: end;">
                                    <h2 style="font-family: 'Tajawal', sans-serif;text-align: end;" class="fs-title">حدثنا عنك </h2>
                                    <textarea style="font-family: 'Tajawal', sans-serif;border: 1px solid #ccc;resize:none" name="description" id="description" cols="30" rows="10" class="from-control">

                                    </textarea>
                                </div>
                                
                               
                                
                                
                                
                                
                                
                                <input  style="font-family: 'Tajawal', sans-serif;border-radius:12px" type="submit" name="make_payment" id="confirmBtn" class="next action-button confirmBtn nextpayBtn" value="تأكيد" />
                            <p class="errorRquired3" style="color:red"></p>
                            </fieldset>

                            <fieldset>
                                <div class="form-card">
                                    <div class="row justify-content-center" style="background: #fff;">
                                        <div class="col-3 col-sm-1 img-error">
                                             <!--<div class="dots-bars-2"></div>-->
                                             <div class="loader"></div>
                                             <img width="90px" src="public/ok-img.png" class="fit-image">
                                             <img width="60px" src="https://www.freeiconspng.com/thumbs/error-icon/round-error-icon-16.jpg" class="fit-image error">
                                        </div>
                                    </div> <br>
                                    <h2 style="font-family: 'Tajawal', sans-serif;" class="fs-title text-center msg-header"></h2> <br><br>
                                    <div style="font-family: 'Tajawal', sans-serif;margin-top:-1rem;background: #fff;" class="row justify-content-center">
                                        <div class="col-12 text-center msg-content">
                                            <h5 style="font-family: 'Tajawal', sans-serif;"></h5>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>
                        </form>
                    </div>
                </div>

                <!--<img src="public/web-03.png" alt="">-->
            </div>









        </div>
    </div>
</div>
    
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.14.0-beta3/js/bootstrap-select.min.js" integrity="sha512-yrOmjPdp8qH8hgLfWpSFhC/+R9Cj9USL8uJxYIveJZGAiedxyIxwNw4RsLDlcjNlIRR4kkHaDHSmNHAkxFTmgg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://unpkg.com/filepond-plugin-file-validate-size/dist/filepond-plugin-file-validate-size.js"></script>
    <script src="https://unpkg.com/filepond-plugin-file-validate-type/dist/filepond-plugin-file-validate-type.js"></script>
    <script src="https://unpkg.com/filepond/dist/filepond.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/datepicker/1.0.10/datepicker.min.js" integrity="sha512-RCgrAvvoLpP7KVgTkTctrUdv7C6t7Un3p1iaoPr1++3pybCyCsCZZN7QEHMZTcJTmcJ7jzexTO+eFpHk4OCFAg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="public/assets/register/hijri/js/momentjs.js"></script>
    <script src="public/assets/register/hijri/js/moment-with-locales.js"></script>
    <script src="public/assets/register/hijri/js/moment-hijri.js"></script>
    <script src="public/assets/register/hijri/js/bootstrap-hijri-datetimepicker.js"></script>
    <script>
        $.ajaxSetup({
              headers: {
                          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              }
        });
        FilePond.registerPlugin(FilePondPluginFileValidateSize,FilePondPluginFileValidateType);
        const inputElement = document.querySelector('#video');
        
        const pond = FilePond.create(inputElement,{
            maxFileSize: '500MB',
            acceptedFileTypes: ['video/*'],
            fileValidateTypeDetectType: (source, type) => new Promise((resolve, reject) => {
                
                // Do custom type detection here and resolve promise
        
                resolve(type);
            })
        });
         FilePond.setOptions({
            server: {
                url: "/vision/upload",
                process:{
                    headers: {
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                    },
                    onload: (response) => { document.getElementById('video_name').value  = response; },
                    onerror: (response) => { alert('please try after one minute'); }
                }
            }
        });
    </script>
    <script>
        $(document).ready(function(){

var current_fs, next_fs, previous_fs; //fieldsets
var opacity;

$(".next").click(function(){





current_fs = $(this).parent();
next_fs = $(this).parent().next();

//Add Class Active
// $("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");

  function validateEmail(email) {
    var re = /^(([a-zA-Z0-9]+)|([a-zA-Z0-9]+((?:\_[a-zA-Z0-9]+)|(?:\.[a-zA-Z0-9]+))*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-zA-Z]{2,6}(?:\.[a-zA-Z]{2})?)$)/;
    return re.test(email);
  }

if(current_fs.data('set') == 1){
    var selectpickerCheck  = $('#selectpicker').val();
    if($('#name').val() == '' || $('#email').val() == '' ||  $('#mobile').val().length < 8 || $('#age').val() == ''|| $('#city').val() == '' || $('#nationality').val() == '' || $('#birthdate_type').val() == ''){
       $('.errorRquired1').text('جميع الحقول مطلوبة');
    }else{
        var email = $("#email").val();
        if (validateEmail(email)) {
                        $.ajaxSetup({
                          headers: {
                              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                          }
                        });
                        $.ajax({
                            'url': 'checkEmail/'+email,
                            'type': 'GET',
                            'dataType': 'json',
                             data: email,
                             cache:false,
                             contentType: false,
                             processData: false,
                            success: function (response) {
                                    $('.errorRquired1').text('');
                                    $('.invalidEmailMSG').css('visibility','hidden');
                                    //show the next fieldset
                                    next_fs.show();
                                    //hide the current fieldset with style
                                    current_fs.animate({opacity: 0}, {
                                    step: function(now) {
                                    // for making fielset appear animation
                                    opacity = 1 - now;
                            
                                    current_fs.css({
                                    'display': 'none',
                                    'position': 'relative'
                                    });
                                    next_fs.css({'opacity': opacity});
                                    },
                                    duration: 600
                                    });
                            },
                            error: function (xhr) {
                                   $("#progressbar li#account").removeClass("active");
                                   $('.errorRquired1').text('هذا البريد الالكتروني مستخدم من قبل شخص آخر');
                            }
                        });

        }else{
            $('.invalidEmailMSG').css('visibility','visible');
            $('.errorRquired1').text('يجب إدخال بريد إلكتروني صالح');
        }

    }
}
if(current_fs.data('set') == 2){
    var file1 = document.getElementById("image");
    var file2 = document.getElementById("video_name");
    var file3 = document.getElementById("poem");
    if(file1.files.length == 0  || file2.value.length == 0  || file3.files.length == 0 ){
      $('.errorRquired2').text('جميع الحقول مطلوبة');
    }else{
        $('.errorRquired2').text('');
        //show the next fieldset
        next_fs.show();
        //hide the current fieldset with style
        current_fs.animate({opacity: 0}, {
        step: function(now) {
        // for making fielset appear animation
        opacity = 1 - now;

        current_fs.css({
        'display': 'none',
        'position': 'relative'
        });
        next_fs.css({'opacity': opacity});
        },
        duration: 600
        });
    }
}

if(current_fs.data('set') == 3){
    if($('#badgeName').val() == '' || $('#badgeSide').val() == '' || $('#badgeJob').val() == ''){
       $('.errorRquired3').text('جميع الحقول مطلوبة');
    }else{
        $('.errorRquired3').text('');
        //show the next fieldset
        next_fs.show();
        //hide the current fieldset with style
        current_fs.animate({opacity: 0}, {
        step: function(now) {
        // for making fielset appear animation
        opacity = 1 - now;

        current_fs.css({
        'display': 'none',
        'position': 'relative'
        });
        next_fs.css({'opacity': opacity});
        },
        duration: 600
        });
    }
}


});

$(".previous").click(function(){

current_fs = $(this).parent();
previous_fs = $(this).parent().prev();

//Remove class active
// $("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");

//show the previous fieldset
previous_fs.show();

//hide the current fieldset with style
current_fs.animate({opacity: 0}, {
step: function(now) {
// for making fielset appear animation
opacity = 1 - now;

current_fs.css({
'display': 'none',
'position': 'relative'
});
previous_fs.css({'opacity': opacity});
},
duration: 600
});
});

$('.radio-group .radio').click(function(){
$(this).parent().find('.radio').removeClass('selected');
$(this).addClass('selected');
});

$(".submit").click(function(){
return false;
})

});


const checkbox = document.getElementById('FieldsetCheck');
const acccccs = document.getElementById('lastAccept');

// checkbox.addEventListener('change', (event) => {
//   if (event.currentTarget.checked) {
//     $(".conditions").css('display','none');
//     $("#msform").css('display','block');
//   } else {
     
//   }
// })

acccccs.addEventListener('click', (event) => {
  if (checkbox.checked) {
      
    $('p.pacceptmsg').css('visibility','hidden');
    $(".conditions").css('display','none');
    $("#msform").css('display','block');
  } else {
     $('p.pacceptmsg').css('visibility','visible');
  }
})



    </script>
    <script>

         $('.nextInfoBtn').click(function(){
              if($('#name').val() == '' || $('#email').val() == '' ||  $('#mobile').val().length < 8 || $('#age').val() == ''|| $('#city').val() == '' || $('#nationality').val() == '' || $('#birthdate_type').val() == ''){

             }else{
                 $("#progressbar li#account").addClass("active");
             }

        });

         $('.nextVisaBtn').click(function(){
            var file11 = document.getElementById("image");
            var file22 = document.getElementById("video_name");
            var file33 = document.getElementById("poem");
            if(file11.files.length == 0  || file22.value.length == 0  || file33.files.length == 0 ){
            }else{
                    $("#progressbar li#payment").addClass("active");
                }
        });

         $('.preVisaBtn').click(function(){
            $("#progressbar li#account").removeClass("active");
        });

        $('.prepayBtn').click(function(){
            $("#progressbar li#payment").removeClass("active");
        });



        $('.nextpayBtn').click(function(){
            

        });

         $('.preConfirmBtn').click(function(){
            $("#progressbar li#services").removeClass("active");
        });


        $('.nextservicesBtn').click(function(){

                if($('#inBahreen').val() == 'No' && $('#member').val() == 'No' && file.files.length == 0 ){

                }else{
                    $("#progressbar li#confirm").addClass("active");
                }
        });

         $('.preservicesBtn').click(function(){
            $("#progressbar li#confirm").removeClass("active");
        });

    </script>
    <script>
    $(function () {
      
            $('#msform').submit(function (e) {
                    e.preventDefault();
                   
                    var full_number = phone_number.getNumber(intlTelInputUtils.numberFormat.E164);
                    $("input[name='mobile'").attr('type','text');
                    $("input[name='mobile'").val(full_number);
                    var name = $('#name').val();
                    var mobile = $('#mobile').val();
                    var email = $('#email').val();
                    
                    var birthdate_type = $('#birthdate_type').val();
                    // var day = $('#day').val();
                    // var month = $('#month').val();
                    // var year = $('#year').val();
                    
                    var hobbies = $('#hobbies').val();
                    var nationality = $('#nationality').val();
                    var city = $('#city').val();
                    var gender = $('#gender').val();
                    var description = $('#description').val();
                    var facbook = $('#facebook_account').val();
                    var instagram = $('#instagram_account').val();
                    var twitter = $('#twitter_account').val();
                
                
                    var fd = new FormData();

                    var url = $(this).attr('action');
                    fd.append('name',name);
                    fd.append('mobile',mobile);
                    fd.append('email',email);
                    
                    fd.append('birthdate_type',birthdate_type);
                    // fd.append('day',day);
                    // fd.append('month',month);
                    // fd.append('year',year);
                    
                    fd.append('nationality',nationality);
                    fd.append('city',city);  
                    fd.append('gender',gender);
                    fd.append('hobbies','');
                    fd.append('facbook',facbook);
                    fd.append('instagram',instagram);
                    fd.append('twitter',twitter);
                    fd.append('description',description);
                    fd.append('image', $('input#image')[0].files[0]);
                    fd.append('video', $('#video_name').val());
                    fd.append('poem', $('input#poem')[0].files[0]);
              
                        $.ajaxSetup({
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                            }
                        });
                        $.ajax({
                            'url': url,
                            'type': 'POST',
                            'dataType': 'json',
                                data: fd,
                                cache:false,
                                contentType: false,
                                processData: false,
                            success: function (response) {
                                        $('.loader').css('display','none');
                                        $('h2.msg-header').text('تسجيلك تم بنجاح');
                                        $('.msg-content h5').text('شكرا لتسجيل مشاركتكم في برنامج شاعر الراية');
                            },
                            error:function(err){
                                alert('هناك خطأ في عملية التسجيل');
                                console.log(err);
                            }
                        });
                
                        // setTimeout(
                        // function() {
                        //             $('.loader').css('display','none');
                        //             $('h2.msg-header').text('تسجيلك تم بنجاح');
                        //             $('.msg-content h5').text('شكرا لتسجيل مشاركتكم في برنامج شاعر الراية');
                        //     }, 2000);
                        
                });

            });
    </script>
       
  
<script>
    var phone_number = window.intlTelInput(document.querySelector("#mobile"), {
     separateDialCode: true,
     preferredCountries:["sa"],
     hiddenInput: "full",
     utilsScript: "//cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.3/js/utils.js"
});
$('#selectpicker').selectpicker();
$('.filter-option-inner-inner').text('قم باختيار واحدة أو أكثر');

 $('#mobile').keypress(function(e) {
    var mobile = $(this).val();
    if(mobile.length == 9){
        e.preventDefault();
    }
});
</script>
<script type="text/javascript">


        $(function () {
            
            initHijrDatePicker();

            //initHijrDatePickerDefault();

            $('.disable-date').hijriDatePicker({

                minDate:"2020-01-01",
                maxDate:"2021-01-01",
                viewMode:"years",
                hijri:true,
                debug:true
            });

        });

        function initHijrDatePicker() {

            $(".hijri-date-input").hijriDatePicker({
                locale: "ar-sa",
                format: "DD-MM-YYYY",
                hijriFormat:"iYYYY-iMM-iDD",
                dayViewHeaderFormat: "MMMM YYYY",
                hijriDayViewHeaderFormat: "iMMMM iYYYY",
                showSwitcher: true,
                allowInputToggle: true,
                showTodayButton: false,
                useCurrent: false,
                viewDate:'1980-01-15',
                isRTL: false,
                viewMode:'months',
                keepOpen: false,
                hijri: false,
                debug: true,
                showClear: true,
                showTodayButton: true,
                showClose: true,
                minDate:'1900-01-01',
                maxDate:'2004-12-31'
            });
        }

        function initHijrDatePickerDefault() {

            $(".hijri-date-input").hijriDatePicker();
            
            $('#birthdate_type').val('');
            $(".hijri-date-input").val('');
        }


</script>
</body>
</html>
<?php /**PATH /home/alrayapoet/public_html/vision/resources/views/registered/index.blade.php ENDPATH**/ ?>