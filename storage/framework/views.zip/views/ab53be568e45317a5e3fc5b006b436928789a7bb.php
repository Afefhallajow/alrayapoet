<div class="main-menu menu-fixed menu-light menu-accordion menu-shadow" data-scroll-to-active="true">
    <div class="navbar-header">
        <ul class="nav navbar-nav flex-row">
            <li class="nav-item mr-auto"><a class="navbar-brand" href="<?php echo e(url('/home')); ?>">
                    
                    <span class="brand-logo">
                            </span>
                    <h2 class="brand-text"> لوحة التحكم</h2>
                </a></li>
            <li class="nav-item nav-toggle"><a class="nav-link modern-nav-toggle pr-0" data-toggle="collapse"><i class="d-block d-xl-none text-primary toggle-icon font-medium-4" data-feather="x"></i><i class="d-none d-xl-block collapse-toggle-icon font-medium-4  text-primary" data-feather="disc" data-ticon="disc"></i></a></li>
        </ul>
    </div>
    <div class="shadow-bottom"></div>
    <div class="main-menu">
        <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation" >
            <li class="br-menu-item">
                <a href="#" class="br-menu-link with-sub " >
                    <i data-feather="layers" class="text-primary"></i>
                    <span class="menu-item-label">البيانات</span>
                </a><!-- br-menu-link -->
                <ul class="br-menu-sub">
                    <li class="sub-item"><a href="<?php echo e(url('/show')); ?>" class="sub-link"><i data-feather="circle" class="text-primary"></i> المتقدمين </a></li>
                </ul>
            </li>
        <!-- br-menu-item -->
        </ul>
    </div>
</div><?php /**PATH /home/festivalgcc/public_html/shaer/resources/views/layouts/menu.blade.php ENDPATH**/ ?>