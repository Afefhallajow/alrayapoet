
<?php $__env->startSection('css'); ?>
    <style>
        .red{
            color:red;
        }
        .error{
            color:red;
        }
        .alert-danger {
            background-color: red !important;
        }
        .dtsb-criteria{
            width:100%;
            margin:auto;
            text-align:center;
        }
        .dtsb-inputCont{
            display: initial;
        }
        div.dtsb-searchBuilder {
            margin-bottom: -2rem;
        }
    </style>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?> 
<div id="content">
                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <!-- DataTales Example -->
                    <div class="card shadow mb-2">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">
                                <a class="btn" data-toggle="modal" data-target="#exampleModal" style="font-weight:bold;float:right;font-size:1.2rem">  جدول التقييمات</a>
                            </h6>
                            <div class="row">
                                  <div class="col-md-12">
                                        <h4 style="text-align:center">الاسم </h4>
                                        <span id="name"></span>
                                  </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered yajra-datatable"  width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>التسلسل</th>
                                            <th>الاسم</th>
                                            <th>البريد الالكتروني</th>
                                            <th>تقييم بشائر</th>
                                            <th>ملاحظات بشائر</th>
                                            <th>تقييم ممدوح</th>
                                            <th>ملاحظات ممدوح</th>
                                            <th>تقييم مشعل</th>
                                            <th>ملاحظات مشعل</th>
                                            <th>المتوسط</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

            </div>
            <!-- /.container-fluid -->

            </div>

<?php $__env->startPush('style'); ?>

    <link href="<?php echo e(asset('assets/SmartWizard/bootstrap.css')); ?>" rel="stylesheet" type="text/css" />
    
    
    
    
    <link href="<?php echo e(asset('assets/SmartWizard/theme-ar.css')); ?>" rel="stylesheet" type="text/css" />

<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>

    <!--<script src="<?php echo e(asset('assets/SmartWizard/jquery.min.js')); ?>"></script>-->

    <!--<script src="<?php echo e(asset('assets/SmartWizard/bootstrap.js')); ?>"></script>-->
    <!--<script src="<?php echo e(asset('assets/SmartWizard/custom_js.js')); ?>"></script>-->

    <!--<script src="<?php echo e(asset('assets/SmartWizard/validator.min.js')); ?>"></script>-->
    <!--<script type="text/javascript" src="<?php echo e(asset('assets/admin/lib/SmartWizard/dist/js/jquery.smartWizard.js')); ?>"></script>-->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-validator/0.5.3/js/bootstrapValidator.js"></script>
    <script src="https://nightly.datatables.net/searchbuilder/js/dataTables.searchBuilder.js?_=40f0e1a3ea332af586366e40955c1713"></script>
    <script type="text/javascript">
    var serialNumber = 0;
    $(function () {

        $.ajaxSetup({
                  headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                  }
        });
        
        var table = $('.yajra-datatable').DataTable({
            
            
            dom: 'Bfrtip',
            buttons: [
                <?php if(Auth::user()->type == 1): ?>
                {
                    extend: 'excel',
                    exportOptions: {
                        columns: [ 1,2,3,4,5,6,7,8,9 ]
                    }
                },
                {
                    extend: 'print',
                    exportOptions: {
                        columns: [1,2,3,4,5,6,7,8,9 ]
                    }
                }
                <?php endif; ?>
            ],
            
            
            ajax: "<?php echo e(route('all-evaluations')); ?>",
            "initComplete": function() {
                  // Select the column whose header we need replaced using its index(0 based)
                  this.api().column(1).every(function() {
                    var column = this;
                    // Put the HTML of the <select /> filter along with any default options 
                    var select = $('<select class="form-control input-sm"><option value="">All</option></select>')
                      // remove all content from this column's header and 
                      // append the above <select /> element HTML code into it 
                      .appendTo($('#name'))
                      // execute callback when an option is selected in our <select /> filter
                      .on('change', function() {
                        // escape special characters for DataTable to perform search
                        var val = $.fn.dataTable.util.escapeRegex(
                          $(this).val()
                        );
                        // Perform the search with the <select /> filter value and re-render the DataTable
                        column
                          .search(val ? '^' + val + '$' : '', true, false)
                          .draw();
                      });
                    // fill the <select /> filter with unique values from the column's data
                    column.data().unique().sort().each(function(d, j) {
                      select.append("<option value='" + d + "'>" + d + "</option>")
                    });
                  });
                },
            columns: [
                {data: 'id', name: 'id'},
                {data: 'name', name: 'name'},
                {data: 'email', name: 'email'},
                {data: 'ev1_percent', name: 'ev1_percent'},
                {data: 'ev2_notes', name: 'ev2_notes'},
                {data: 'ev2_percent', name: 'ev2_percent'},
                {data: 'ev2_notes', name: 'ev2_notes'},
                {data: 'ev3_percent', name: 'ev3_percent'},
                {data: 'ev3_notes', name: 'ev3_notes'},
                {}
            ] ,
            ordering: true,
            columnDefs: [
                { orderable: true, targets: 9 },
                {
                // For Responsive
                responsivePriority: 14,
                targets: 0
                },
                {
                    targets: 0,
                    render: function (data, type, full) {
                        return ++serialNumber;

                    }
                },
                {
                    targets: 1,
                    render: function (data, type, full) {
                        var text = full['name'];
                        return text;

                    }
                },
                {
                    targets: 2,
                    render: function (data, type, full) {
                        var text = full['email'];
                        return text;

                    }
                },
                {
                    targets: 3,
                    render: function (data, type, full) {
                        var text = full['ev1_percent'];
                        if(!text)
                            return '-';
                        return parseFloat(text).toFixed(2)+'%';

                    }
                },
                {
                    targets: 4,
                    render: function (data, type, full) {
                        var text = full['ev1_notes'];
                        if(!text)
                            return '-';
                        return text;
                    }
                },
                {
                    targets: 5,
                    render: function (data, type, full) {
                        var text = full['ev2_percent'];
                        if(!text)
                            return '-';
                        return parseFloat(text).toFixed(2)+'%';

                    }
                },
                {
                    targets: 6,
                    render: function (data, type, full) {
                        var text = full['ev2_notes'];
                        if(!text)
                            return '-';
                        return text;
                    }
                },
                {
                    targets: 7,
                    render: function (data, type, full) {
                        var text = full['ev3_percent'];
                        if(!text)
                            return '-';
                        return parseFloat(text).toFixed(2)+'%';

                    }
                },
                {
                    targets: 8,
                    render: function (data, type, full) {
                        var text = full['ev3_notes'];
                        if(!text)
                            return '-';
                        return text;
                    }
                }
                ,
                {
                    targets: 9,
                    render: function (data, type, full) {
                       var ev1 = full['ev1_percent'];
                       if(!ev1)
                            ev1 = 0;
                            
                       var ev2 = full['ev2_percent'];
                       if(!ev2)
                            ev2 = 0;
                            
                       var ev3 = full['ev3_percent'];
                        if(!ev3)
                            ev3 = 0;
                            
                        var avg = (parseFloat(ev1)+parseFloat(ev2)+parseFloat(ev3))/3;
                        
                        return avg.toFixed(2)+'%';
                       
                    }
                }
            ]
        });

    });
    </script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alrayapoet/public_html/vision/resources/views/admin/reviewEvaluations/index.blade.php ENDPATH**/ ?>