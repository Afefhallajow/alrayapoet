<?php

namespace App\Http\Livewire;

use App\Models\countries;
use App\Models\Registered;
use App\Models\settings;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Livewire\Component;
use Livewire\WithFileUploads;
use phpDocumentor\Reflection\Types\This;
use Str;
class Reg extends Component
{ use WithFileUploads;
//protected  $rules=['video'=> 'file|max:1000000'];
    public static function rules()
    {
        return ['video'=> 'file|max:1000000'];
    }
public $name,$email,$gender,$nationality,$city,$mobile,$image,$image_name,$poem_name,$video,$poem,$description
,$video_name,$birthdate_type,$facbook,$instagram,$twitter,$job,$city1,$area,$anyshare,$anytalent,$study;
public $check;


    public $currentStep = 1;
    public function ZeroStepSubmit()
    {
        $this->currentStep=1;
    }
    public function firstStepSubmit()
    {
/**            $this->validate([
        'email' => 'required|email',

        'name' => 'required',
        'gender' => 'required',
        'nationality' => 'required',
        'city' => 'required',
        'mobile' => 'required',
        'city1' => 'required',

        'study' => 'required',
    ]);***/
        $this->currentStep = 2;
    }

    public function secondStepSubmit()
    {$this->validate([
        'image' => 'required',
//        'video' => 'max:1000000|required|file|mimetypes:video/mp4,video/mpeg,video/x-matroska',        'poem' => 'required',

    ]);
        $file1 = $this->image;
        $this->image_name=Str::random(7).'.'. $this->image->getClientOriginalExtension();
       $this->poem_name=Str::random(7).'.'. $this->poem->getClientOriginalExtension();
  //      $this->video_name_name=Str::random(7).'.'. $this->video->getClientOriginalExtension();

        $this->image->storeAs('images', $this->image_name, $disk = 'public');
//        $this->video->storeAs('videos', $this->video_name, $disk = 'public');
        $this->image->storeAs('poems', $this->poem_name, $disk = 'public');


        $this->currentStep = 3;

    }
    public function back($step)
    {
        $this->currentStep = $step;
    }

    public function thirdStepSubmit()
    {

        try {
            $data = array('memberEmail' => $this->email);
            Mail::send('email.welcome',$data,function($m) use($data){
                $m->from('registration@alrayapoet.com');
                $m->to($data['memberEmail'])->subject('Thanks For Registration!');
            });
        }
        catch (\Exception $e) {
            return false;

        }



        $active=settings::all();
        $active1=$active[0]->activeseason;
        $newRecord = Registered::create([
        'name' => $this->name,
            'email' => $this->email,
            'age' => $this->birthdate_type,
            'gender' => $this->gender,
            'nationality' => $this->nationality,
            'city' => $this->city,
            'city1' => $this->city1,
            'job'=>$this->job,
            'mobile' => $this->mobile,
            'hobbies' => $this->hobbies,
            'description' => $this->description,
            'study' => $this->study,
            'anytalent' => $this,
            //  'anytalenti' => $request->anytalenti,
            'anyshare' => $this,
//    'description' => $request->description,


            'image' => $this->image_name,
            'video' => $this->video_name,
            'poem' => $this->poem_name,
            'facbook' => $this->facbook,
            'instagram' => $this->instagram,
            'twitter' => $this->twitter,
            'season'=>2,
            'area'=>$this->area
        ]);
toastr()->success('تم التسجيل بنجاح');
    }



    public function render()
    {
        return view('livewire.add-visa',['countries'=>countries::all()]);
    }
}
