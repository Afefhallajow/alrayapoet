<div>
    @if($currentStep == 2)
        <div class="row setup-content" id="step-2">
            <div class="col-xs-12" style="text-align: center">
                <div class="formrow">
                    <div class="col-12 ">
                        <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="#dbad3e" class="bi bi-check-lg" viewBox="0 0 16 16">
                            <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                        </svg>
                        <br>
                        <h1 style="color:#dbad3e; " >تم التعديل بنجاح!</h1>
                        <p class='par'  class="mt-5">
                            شكراً لتسجيل مشاركتكم في برنامج شاعر الراية "الموسم الثاني".     </p>
                        <p class='par'  >تمنياتنا لك بالتوفيق</p>
                        <div class="d-flex justify-content-center align-items-center">


                        </div>

                    </div>
                </div>
            </div>
        </div>
    @endif
</div>
